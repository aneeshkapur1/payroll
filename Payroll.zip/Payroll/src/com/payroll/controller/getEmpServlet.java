package com.payroll.controller;

import java.io.IOException;
import java.util.List;

import javax.servlet.ServletConfig;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.payroll.dao.DepartmentDAO;
import com.payroll.dao.EmployeeDAO;
import com.payroll.dao.SkillDAO;
import com.payroll.exceptions.PayrollException;
import com.payroll.model.Department;
import com.payroll.model.Employee;
import com.payroll.model.skills;

/**
 * Servlet implementation class getEmpServlet
 */
@WebServlet("/getEmpServlet")
public class getEmpServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public getEmpServlet() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see Servlet#init(ServletConfig)
	 */
	public void init(ServletConfig config) throws ServletException {
		// TODO Auto-generated method stub
	}

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		response.getWriter().append("Served at: ").append(request.getContextPath());
		
		String flag = "";
		
		String eid=	request.getParameter("empId");
		flag = request.getParameter("flag");
		 Boolean f = Boolean.parseBoolean(flag);
		
		System.out.println(eid);
		
		int empId=Integer.parseInt(eid);
		
		EmployeeDAO employeeDAO=new EmployeeDAO();
		SkillDAO skilldao = new SkillDAO();
		DepartmentDAO departmentdao = new DepartmentDAO();
		try {
			
			
			List<skills> s = skilldao.fetchSkills();
			Employee employee=employeeDAO.fetchEmployeeById(empId);
			List<Department> dept = departmentdao.fetchDepartments();
			System.out.println(employee);
			request.setAttribute("list1", s);
		
			
			request.setAttribute("employee", employee);
			request.setAttribute("departmentList", dept);
			
		
		} catch (PayrollException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			request.setAttribute("error", "Some internal DB error");
		}
		
		if(f == true){
		
		request
		.getRequestDispatcher("showemp.jsp")
		.forward(request, response);
		
		}
		else
		{
			request
			.getRequestDispatcher("deleteEmp.jsp")
			.forward(request, response);
			
		}
		
	}

}
