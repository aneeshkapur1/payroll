package com.payroll.controller;

import java.io.IOException;
import java.sql.Connection;
import java.sql.SQLException;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.payroll.dao.EmployeeDAO;
import com.payroll.dao.SkillDAO;
import com.payroll.dao.SkillSetDao;
import com.payroll.exceptions.PayrollException;
import com.payroll.model.Address;
import com.payroll.model.Department;
import com.payroll.model.Employee;
import com.payroll.model.EmployeeSkillSet;
import com.payroll.model.skills;
import com.payroll.services.EmployeeService;
import com.payroll.util.ConnectionUtil;

/**
 * Servlet implementation class RegistrationServlet
 */
@WebServlet("/RegistrationServlet")
public class RegistrationServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public RegistrationServlet() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		String empName = request.getParameter("empname");
		String Salary = request.getParameter("empSalary");
		double empSalary = Double.parseDouble(Salary);
		String did = request.getParameter("DepartmentId");
		int departmentId = Integer.parseInt(did);
		String street = request.getParameter("empstreet");
		String city = request.getParameter("empcity");
		String state = request.getParameter("empstate");
		String country = request.getParameter("empcountry");
		
		String[] skills = request.getParameterValues("dskill");
		Employee employee = new Employee(0,empName,empSalary);
		
		Department department= new Department();
		department.setDepartmentId(departmentId);
		
		Address address = new Address (0,street,city,state,country);
		
		employee.setAddress(address);
		employee.setDepartment(department);
		Connection connObj = null;
		try{
			
			connObj = ConnectionUtil.getConnection();
			connObj.setAutoCommit(false);
		EmployeeService employeeService = new EmployeeService();
		int empId = employeeService.registerEmployee(connObj, employee);
		employee.setEmpId(empId);
		
		SkillSetDao skillsetDao = new SkillSetDao(); 
		for(String str : skills)
		{
			int skillId = Integer.parseInt(str);
			EmployeeSkillSet employeeSkillSet = new EmployeeSkillSet();
			skills skill = new skills();
			skill.setSkillId(skillId);
			employeeSkillSet.setEmpskillSetId(skillId);
			employeeSkillSet.setSkills(skill);
			employeeSkillSet.setEmployee(employee);
			skillsetDao .registerSkillSet(connObj, employeeSkillSet);
			connObj.commit();
		}
		connObj.commit();
		
		if(empId != 0)
		{
			System.out.println("Your EMployee Id is" + empId);
			System.out.println("Please Remember for future");
		}
		RequestDispatcher rd =  request.getRequestDispatcher("RegisterSuccessful.html");
		rd.forward(request,response);
//		
		}catch(SQLException s)
		{
			try {
				connObj.rollback();
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			s.printStackTrace();
		} catch (PayrollException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		finally
		{
			try
			{
				if(connObj != null)
				{
					connObj.close();
				}
				
			}catch(SQLException s)
			{
				s.printStackTrace();
			}
		}
	}

}
