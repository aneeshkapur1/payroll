package com.payroll.controller;

import java.io.IOException;
import java.io.PrintWriter;
import java.util.List;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletConfig;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.payroll.dao.EmployeeDAO;
import com.payroll.dao.LoginDAO;
import com.payroll.dao.SkillDAO;
import com.payroll.exceptions.PayrollException;
import com.payroll.model.Employee;
import com.payroll.model.LoginDetails;
import com.payroll.model.LoginDetailsValidate;
import com.payroll.model.skills;

/**
 * Servlet implementation class LoginServelt
 */
@WebServlet(description = "Servlet for Login Check", urlPatterns = { "/LoginServlet" })
public class LoginServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public LoginServlet() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see Servlet#init(ServletConfig)
	 */
	public void init(ServletConfig config) throws ServletException {
		// TODO Auto-generated method stub
		System.out.println("Server Initialized");
	}

	/**
	 * @see Servlet#destroy()
	 */
	public void destroy() {
		// TODO Auto-generated method stub
		System.out.println("Server Destroyed");
	}

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	
	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		
		System.out.println("POst of login servlet");
		String username = request.getParameter("username");
		String password = request.getParameter("password");
		
		LoginDetailsValidate validate=new LoginDetailsValidate();
		
		PrintWriter out = response.getWriter();
		LoginDetails login = new LoginDetails(username,password);
		LoginDAO dao = new LoginDAO();
		boolean check = false;
		String page = "login.jsp";
		try {
			boolean checkLogin=	validate.validateLoginDetails(login);
			System.out.println("validate check"+checkLogin);
			check = dao.loginCheck(login);
		
			if(checkLogin){
				check = dao.loginCheck(login);
				System.out.println("db check"+check);
		if(check)
		{
			HttpSession session = request.getSession();
			session.setAttribute("user", login);
			
			System.out.println("Logged in" + username );
			EmployeeDAO empdao = new EmployeeDAO();
			List<Employee> employees = empdao.fetchAllData(null);
			
			request.setAttribute("list", employees);
			
			page = "Success.jsp";
			
			
	 	}
		else
		{
			request.setAttribute("error", "Wrong Login and Password");
			System.out.println("Cannot Login" + "error page");
			page = "Login.jsp";
			
		}
			}else{
				
				throw new PayrollException("Username and Password should correctly be provided");
			}
		RequestDispatcher rd =  request.getRequestDispatcher(page);
		rd.forward(request,response);
		}catch (PayrollException e) {
			// TODO Auto-generated catch block
			request.setAttribute("error", "Some internal error contact to db admin");
		}
	}

}
