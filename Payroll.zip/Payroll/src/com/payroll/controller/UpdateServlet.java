package com.payroll.controller;

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.SQLException;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.payroll.dao.AddressDAO;
import com.payroll.dao.EmployeeDAO;
import com.payroll.dao.SkillSetDao;
import com.payroll.exceptions.PayrollException;
import com.payroll.model.Address;
import com.payroll.model.Department;
import com.payroll.model.Employee;
import com.payroll.model.EmployeeSkillSet;
import com.payroll.util.ConnectionUtil;

/**
 * Servlet implementation class UpdateServlet
 */
@WebServlet("/UpdateServlet")
public class UpdateServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public UpdateServlet() {
        super();
        // TODO Auto-generated constructor stub
    }


	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
	Connection connObj=null;
		
		String eid=request.getParameter("empId");
		int empId=Integer.parseInt(eid);
		String empName = request.getParameter("empName");
		String salary = request.getParameter("empSalary");
		double empSalary = Double.parseDouble(salary);
		Employee employee=new Employee(empId, empName, empSalary);
		
		
		String did = request.getParameter("DepartmentId");
		int departmentId = Integer.parseInt(did);
		
		Department department=new Department();
		department.setDepartmentId(departmentId);
		employee.setDepartment(department);
		
		
		String aid = request.getParameter("addressId");
		int addressId=Integer.parseInt(aid);
		String street = request.getParameter("empstreet");
		String city = request.getParameter("empcity");
		String state = request.getParameter("empstate");
		String country = request.getParameter("empcountry");
		
		Address address=new Address(addressId, street, city, state, country);
		

		String[] skills = request.getParameterValues("skills");
		
		
		
		System.out.println(skills);
		
		try {
				EmployeeDAO employeeDAO=new EmployeeDAO();
				connObj=ConnectionUtil.getConnection();
				connObj.setAutoCommit(false);
				
				employeeDAO.updateEmployee(connObj, employee);
				
				
				AddressDAO addressDAO=new AddressDAO();
				addressDAO.updateAddress(connObj, address);
				
			SkillSetDao dao=new SkillSetDao();
					dao.removeSkillSet(connObj, empId);
				for (String skillId:skills) {
				
					EmployeeSkillSet skillSet=new EmployeeSkillSet();
					skillSet.setEmpskillSetId(Integer.parseInt(skillId));
					skillSet.setEmployee(employee);
					dao.registerSkillSet(connObj, skillSet);
				}
				
				
				PrintWriter out=response.getWriter();
				out.write("SuccessFull, Output");
				connObj.commit();
				out.print("Updated successfully");
				
		} catch (PayrollException e) {
			// TODO Auto-generated catch block
			try {
				connObj.rollback();
			} catch (SQLException e1) {
				// TODO Auto-generated catch block
				e1.printStackTrace();
			}
			e.printStackTrace();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			try {
				connObj.rollback();
			} catch (SQLException e1) {
				// TODO Auto-generated catch block
				e1.printStackTrace();
			}
			
			e.printStackTrace();
			
			
		}
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
	
	}
}
