package com.payroll.controller;

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.SQLException;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.payroll.dao.AddressDAO;
import com.payroll.dao.EmployeeDAO;
import com.payroll.dao.SkillSetDao;
import com.payroll.exceptions.PayrollException;
import com.payroll.model.Address;
import com.payroll.model.Department;
import com.payroll.model.Employee;
import com.payroll.model.EmployeeSkillSet;
import com.payroll.services.AddressService;
import com.payroll.services.EmployeeService;
import com.payroll.services.SkillSetService;
import com.payroll.util.ConnectionUtil;

/**
 * Servlet implementation class DeleteServlet
 */
@WebServlet("/DeleteServlet")
public class DeleteServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public DeleteServlet() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {

		Connection connObj = null;
		PrintWriter out=response.getWriter();
		
		String eId = request.getParameter("empId");
		int empId = Integer.parseInt(eId);

		String addId = request.getParameter("addressId");
		int addressId = Integer.parseInt(addId);

		try {
			connObj = ConnectionUtil.getConnection();
            connObj.setAutoCommit(false);
            
			SkillSetService skillSetService = new SkillSetService();
			int count1 = skillSetService.removeSkillSet(connObj, empId);

			EmployeeService employeeService = new EmployeeService();
			int count3 = employeeService.DeleteEmployee(connObj, empId);

			AddressService addressService = new AddressService();
			int count2 = addressService.DeleteAddress(connObj, addressId);
			
			
			connObj.commit();
			out.print("Succesfuly Deleted");
			

		} catch (PayrollException e) {
			// TODO Auto-generated catch block
			System.out.println("Internal DB error has occured");
			try {
				connObj.rollback();
			} catch (SQLException e1) {
				// TODO Auto-generated catch block
				e1.printStackTrace();
			}
			e.printStackTrace();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} finally {

			try {

				if (connObj != null)
					connObj.close();

			} catch (SQLException e) {
				// TODO Auto-generated catch block
				String message = "Error while closing objects." + e;
				e.printStackTrace();
			}

		}

	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
}