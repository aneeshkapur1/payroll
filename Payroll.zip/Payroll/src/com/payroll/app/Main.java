package com.payroll.app;
import java.sql.Connection;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import com.payroll.dao.AddressDAO;
import com.payroll.dao.EmployeeDAO;
import com.payroll.dao.SkillSetDao;
import com.payroll.exceptions.PayrollException;
import com.payroll.model.Address;
import com.payroll.model.Department;
import com.payroll.model.Employee;
import com.payroll.model.EmployeeSkillSet;

import com.payroll.model.skills;
import com.payroll.util.ConnectionUtil;

public class Main {
	
	public static void main(String []args) throws SQLException
	{
		Connection connObj = null;
		//LoginDetails login = new LoginDetails("Aneesh","Kapur@123" );
		//LoginDAO dao = new LoginDAO();
		//boolean check = dao.loginCheck(login);
		
		
//		if(check)
//		{
//			System.out.println("Logged in" +"Homepage displayed");
//		}
//		else
//		{
//			System.out.println("Cannot Login" + "error page");
//		}
		EmployeeDAO employeeDAO = new EmployeeDAO();
		List<Employee> list=employeeDAO.fetchAllData(null);
		list.forEach(System.out::println);
		
		List<Employee> list1=employeeDAO.fetchAllData("tk");
		list1.forEach(System.out::println);
		try{
		 connObj = ConnectionUtil.getConnection();
		 connObj.setAutoCommit(false);
		Department d = new Department(5,"HR","CHN");
		Address address = new Address(5,"whitehouse","chennai","Tamil Nadu","India");
		AddressDAO addressDao = new AddressDAO();
		int addressId  = addressDao.registerAddress(connObj,address);
		address.setAddressId(addressId);
		skills skill1 = new skills(1,"java");
		skills skill2 = new skills(2,"c");
		
		List<skills> list11 = new ArrayList<skills>();
		list11.add(skill1);
		list11.add(skill2);
		
		Employee employee = new Employee(0,"surbhi",134);
		employee.setAddress(address);
		employee.setDepartment(d);
		
		EmployeeDAO empDao = new EmployeeDAO();
		int empId = empDao.registerEmployee(connObj, employee);
		System.out.println("Emp Id of employee is" + empId);
		employee.setEmpId(empId);
		
		EmployeeSkillSet skillSet1 = new EmployeeSkillSet(0,skill1,employee);
		EmployeeSkillSet skillSet2 = new EmployeeSkillSet(0,skill2,employee);
		
		SkillSetDao skillSetDao = new SkillSetDao();
		skillSetDao.registerSkillSet(connObj, skillSet1);
		skillSetDao.registerSkillSet(connObj, skillSet2);
		
		connObj.commit();
		
		}catch(PayrollException | SQLException s)
		{
			s.printStackTrace();
			try
			{
				connObj.rollback();
			}catch(SQLException e1)
			{
				e1.printStackTrace();
			}
			
		}
		finally
		{
			if(connObj != null )
			{
				try{
				connObj.close();
				}
				catch(SQLException E)
				{
					System.out.println("Error while closing");
				}
			}
		}
		
	}
}
