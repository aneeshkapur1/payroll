package com.payroll.app;

import java.util.List;

import org.springframework.context.annotation.AnnotationConfigApplicationContext;
import org.springframework.context.annotation.ComponentScan;

import com.payroll.dao.LoginDAO;
import com.payroll.model.Employee;
import com.sun.org.apache.bcel.internal.generic.LUSHR;


@ComponentScan({"com.payroll.model","com.payroll.somepackage"})

public class MainSpringAnnotation {

	public MainSpringAnnotation() {
		// TODO Auto-generated constructor stub
	}

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		AnnotationConfigApplicationContext context=
				new AnnotationConfigApplicationContext(SpringConfig.class);
		
	LoginDAO d=	(LoginDAO)context.getBean("login");
		System.out.println(d);
		
	Employee e=	context.getBean("employee",Employee.class);
	System.out.println(e.hashCode());
	
	Employee e2=	context.getBean("employee",Employee.class);
	System.out.println(e2.hashCode());
	
	
	
List<Employee> l= (List<Employee>)context.getBean("list");
	
	System.out.println(l);

	}

}
