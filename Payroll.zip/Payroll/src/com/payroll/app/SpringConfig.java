package com.payroll.app;

import java.sql.SQLException;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.ComponentScan;
import org.springframework.context.annotation.ComponentScans;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.Scope;

import com.payroll.dao.EmployeeDAO;
import com.payroll.dao.LoginDAO;
import com.payroll.exceptions.PayrollException;
import com.payroll.model.Address;
import com.payroll.model.Department;
import com.payroll.model.Employee;
import com.payroll.util.ConnectionUtil;



@Configuration
public class SpringConfig {

	
	@Bean(name="list")
	List<Employee> getList() throws PayrollException, SQLException{
		
		return new EmployeeDAO().fetchAllData( null);
		
	}
	

	@Bean(name="employee")
	@Scope(scopeName="prototype")
	Employee getEmployee(){
	
		return new Employee(1234,"raju",1234.45);
	}
	
	@Bean(name="address")
	Address getAddress(){
		
		return new Address(1, "thripakkma", "chennai", "TN", "IN");
	
	}
	
	@Bean(name="department")
	Department getDepartment(){
		
		return new Department(123, "HR", "Chn");	
	}
	
	
	
	
	@Bean(name="login")
	LoginDAO getLoginDAO(){
		
		return new LoginDAO();
		
	}
	
	
	
	
	
	
	
}
