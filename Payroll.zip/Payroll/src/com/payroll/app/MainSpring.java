package com.payroll.app;
import java.sql.Connection;
import java.sql.SQLException;
import java.util.List;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;
import org.springframework.core.io.*;

import com.payroll.dao.EmployeeDAO;
import com.payroll.model.Employee;


  

public class MainSpring {

	public MainSpring() {
		// TODO Auto-generated constructor stub	}
	}
	    public static void main(String[] args) throws SQLException {  
	          
	    	ApplicationContext context =   
	    		    new ClassPathXmlApplicationContext("spring-config.xml"); 
	    	
	    	  Employee s=(Employee)context.getBean("emp1");  
	          System.out.println(s);
	          
	          System.out.println(s.hashCode());
	      	Employee emp2=	context.getBean("emp1",Employee.class);
	      	System.out.println(emp2);
	      	System.out.println(emp2.hashCode());
	      	
	      	Employee empRaju=null;
	    	empRaju=(Employee)context.getBean("emp2");
	    	
	    	System.out.println(empRaju);
	    	
	    	EmployeeDAO dao=	context.getBean("dao", EmployeeDAO.class);



	    	List<Employee> eList= dao.fetchAllData(null);
	    			System.out.println(eList);
	    }  
	}  

