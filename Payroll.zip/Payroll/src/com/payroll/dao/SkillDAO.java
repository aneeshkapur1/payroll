package com.payroll.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import com.payroll.exceptions.PayrollException;
import com.payroll.model.Address;
import com.payroll.model.Department;
import com.payroll.model.Employee;
import com.payroll.model.skills;
import com.payroll.util.ConnectionUtil;

public class SkillDAO {
	
	
	public int registerSkills( skills skill) throws SQLException, PayrollException
	{
		Connection connObj = null;
		String query = "Insert into skills(skill_name) values(?)";
		PreparedStatement pstmt = null;
		ResultSet result = null;
		int count = 0;
		int generatedId = 0;
		
		try{
			connObj = ConnectionUtil.getConnection();
			pstmt = connObj.prepareStatement(query);
			pstmt.setString(1, skill.getSkillName());
			count = pstmt.executeUpdate();
			
			result = pstmt.getGeneratedKeys();
			if(result.next())
			{
				generatedId = result.getInt(1);
			}
		
	}catch(SQLException s)
		{
		
		s.printStackTrace();
		throw new PayrollException("connection or query problem" + s);
	}
	catch(Exception e)
	{
		System.out.println("Exception");
		throw new PayrollException("connection or query problem" + e);
		
	}finally
	{
		
		if(pstmt != null)
		{
			try
			{
				pstmt.close();
				
			}
			catch(SQLException e)
			{
				e.printStackTrace();
				throw new PayrollException("connection or query problem" + e);
			}
		}
		if(connObj != null)
		{
			try
			{
				connObj.close();
				
			}
			catch(SQLException e)
			{
				e.printStackTrace();
				throw new PayrollException("connection or query problem" + e);
			}
		}
	}
		
return generatedId;
}
public List<skills> fetchSkills() {
		
		List<skills> list1 = new ArrayList<skills>();
		String query = "select * from skills";
		
		Connection conn = null;
		PreparedStatement stmt = null;
		ResultSet rs = null;
		skills s = null;
		try {
			conn = ConnectionUtil.getConnection();
			stmt = conn.prepareStatement(query);
			rs=stmt.executeQuery();
			
			while(rs.next())
			{
				int skillId = rs.getInt("skill_id");
				String skillName=rs.getString("skill_name");
				 s = new skills(skillId,skillName);
				list1.add(s);
			}

		} catch (SQLException e) {
			System.out.println(e.getMessage());
		} finally {
			try {
				if (stmt != null)
					stmt.close();
				if (rs != null)
					rs.close();
				if (conn != null)
					conn.close();
			} catch (SQLException e1) {
				// TODO Auto-generated catch block
				e1.printStackTrace();
			}
		}

		return list1;
	}

	
	
	
	
	
}
