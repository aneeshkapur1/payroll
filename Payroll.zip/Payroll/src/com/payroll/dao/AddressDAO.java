package com.payroll.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import com.payroll.exceptions.PayrollException;
import com.payroll.model.Address;
import com.payroll.model.Employee;
import com.payroll.util.ConnectionUtil;

public class AddressDAO {

	public int DeleteAddress(Connection connObj, int aid) throws PayrollException {
		int count = 0;
		String query = "delete from emp_address where address_id=?";

		// Connection connObj = null;
		PreparedStatement pstmt = null;
		ResultSet result = null;

		try {
			// connObj = ConnectionUtil.getConnection();
			pstmt = connObj.prepareStatement(query);
			pstmt.setInt(1,aid);
			
			count=pstmt.executeUpdate();


		} catch (SQLException e) {
			// TODO Auto-generated catch block
			String message = "Error while deleting Employee data." + e;
			throw new PayrollException(message);
		} catch (Exception e) {
			String message = "Error while deleting Employee data." + e;
			throw new PayrollException(message);
		} finally {

			try {
				if (pstmt != null)
					pstmt.close();
				if (result != null)
					result.close();
				/*
				 * if (connObj != null) connObj.close();
				 */
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				String message = "Error while closing objects." + e;
				throw new PayrollException(message);
			}

		}
		return count;
	}

	
		
		public int registerAddress(Connection connObj, Address a) throws PayrollException
		{
			String query = "Insert into emp_address(street,city,state,country) values(?,?,?,?)";
			PreparedStatement pstmt = null;
			ResultSet result = null;
			int count = 0;
			int generatedId = 0;
			
			try{

				pstmt = connObj.prepareStatement(query);
				pstmt.setString(1, a.getStreet());
				pstmt.setString(2, a.getCity());
				pstmt.setString(3, a.getState());
				pstmt.setString(4, a.getCountry());
				
				count = pstmt.executeUpdate();
				
				result = pstmt.getGeneratedKeys();
						if(result.next())
						{
							generatedId = result.getInt(1);
						}
				}
			catch(SQLException s)
			{
					throw new PayrollException("connection or query problem" + s);
			}
		finally
		{
			
			if(pstmt != null)
			{
				try
				{
					pstmt.close();
					
				}
				catch(SQLException e)
				{
					e.printStackTrace();
				}
			}
			
		}
			
	return generatedId;
	}
		
		public int updateAddress(Connection connObj,Address address) throws PayrollException{
			
			int count=0;
			boolean flag = false;
			String query = "update emp_address set street=?,city=?,state=?,country=? "
					+ "where address_id=?";
			//Connection connObj = null;
			PreparedStatement pstmt = null;
			ResultSet result = null;

			try {
				//connObj = ConnectionUtil.getConnection();
				pstmt = connObj.prepareStatement(query);
				pstmt.setString(1, address.getStreet());
				pstmt.setString(2,  address.getCity());
				pstmt.setString(3,  address.getState());
				pstmt.setString(4,  address.getCountry());
				pstmt.setInt(5,  address.getAddressId());
				
				count= pstmt.executeUpdate();
				
				
				
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				throw new PayrollException("Address DAO has problem"+e);

			} finally {
				try {
					if (result != null) {
						result.close();
					}

					if (pstmt != null) {
						pstmt.close();
					}
					
					/*if (connObj != null) {
						connObj.close();
					}*/
				} catch (SQLException e) {
					// TODO Auto-generated catch block
					throw new PayrollException("Error while closing Object " + e);

					
				}
			}

			return count;
			
		}

}


