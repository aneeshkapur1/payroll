package com.payroll.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import com.payroll.exceptions.PayrollException;
import com.payroll.model.EmployeeSkillSet;
import com.payroll.util.ConnectionUtil;

public class SkillSetDao {
	public int registerSkillSet(Connection connObj, EmployeeSkillSet emp) throws SQLException, PayrollException
	{
		String query = "Insert into emp_skillset(fk_skill_id,fk_emp_id) values(?,?)";
		PreparedStatement pstmt = null;
		ResultSet result = null;
		int count = 0;
		int generatedId = 0;
		
		try{
		
			pstmt = connObj.prepareStatement(query);
			pstmt.setInt(1,emp.getEmpskillSetId());
			pstmt.setInt(2, emp.getEmployee().getEmpId());
			
			count = pstmt.executeUpdate();
			
			result = pstmt.getGeneratedKeys();
			if(result.next())
			{
				generatedId = result.getInt(1);
			}
		}
//	
		catch(SQLException s)
		{
			s.printStackTrace();
			throw new PayrollException("connection or query problem" + s);
	
	}
	catch(Exception o)
	{
		System.out.println("Exception");
		throw new PayrollException("connection or query problem" + o);
		
		
	}finally
	{
		
		if(pstmt != null)
		{
			try
			{
				pstmt.close();
				
			}
			catch(SQLException o)
			{
				o.printStackTrace();
				throw new PayrollException("connection or query problem" + o);
				
			}
		}
		
	}
//		
return generatedId;
}
	
	public int removeSkillSet(Connection connObj,int empId) throws PayrollException{
		
		int count=0;
		boolean flag = false;
		String query = "delete from emp_skillset where fk_emp_id=?";
		//Connection connObj = null;
		PreparedStatement pstmt = null;
		
		try {
			//connObj = ConnectionUtil.getConnection();
			pstmt = connObj.prepareStatement(query);
			pstmt.setInt(1, empId);
				
			count = pstmt.executeUpdate();
			
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			throw new PayrollException("EmployeeSkillset problem"+e);
			

		} finally {
			try {
				
				if (pstmt != null) {
					pstmt.close();
				}
				
				/*if (connObj != null) {
					connObj.close();
				}*/
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				throw new PayrollException("Error while closing Object " + e);
			}
		}

		
		
		
		return count;
		
	}



}
