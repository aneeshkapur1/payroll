package com.payroll.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import com.payroll.exceptions.PayrollException;
import com.payroll.model.Department;

import com.payroll.util.ConnectionUtil;

public class DepartmentDAO {
	
	public int registerDepartment(Connection connObj, Department dept) throws SQLException, PayrollException
	{
		String query = "Insert into department(dept_name,dept_location) values(?,?)";
		PreparedStatement pstmt = null;
		int count = 0;
		ResultSet result = null;
		int generatedId = 0;
		
		try{
	
			pstmt = connObj.prepareStatement(query);
			pstmt.setString(1, dept.getDepartmentName());
			pstmt.setString(2, dept.getDepartmentLocation());
			
			count = pstmt.executeUpdate();
			
			result = pstmt.getGeneratedKeys();
			if(result.next())
			{
				generatedId = result.getInt(1);
			}
			
		}
	catch(SQLException s)
		{
		s.printStackTrace();
		throw new PayrollException("connection or query problem" + s);
		
	}
	catch(Exception e)
	{
		System.out.println("Exception");
		throw new PayrollException("connection or query problem" + e);
		
		
	}finally
	{
		
		if(pstmt != null)
		{
			try
			{
				pstmt.close();
				
			}
			catch(SQLException e)
			{
				e.printStackTrace();
				throw new PayrollException("connection or query problem" + e);
			
			}
		}
		
	}
		
return generatedId;
}
public List<Department> fetchDepartments() {
		
		List<Department> list1 = new ArrayList<Department>();
		String query = "select * from department";
		
		Connection conn = null;
		PreparedStatement stmt = null;
		ResultSet rs = null;
		Department d = null;
		try {
			conn = ConnectionUtil.getConnection();
			stmt = conn.prepareStatement(query);
			rs=stmt.executeQuery();
			
			while(rs.next())
			{
				int departmentId = rs.getInt("dept_id");
				String departmentName=rs.getString("dept_name");
				String departmentLocation = rs.getString("dept_location");
				 d = new Department(departmentId,departmentName,departmentLocation);
				list1.add(d);
			}

		} catch (SQLException e) {
			System.out.println(e.getMessage());
		} finally {
			try {
				if (stmt != null)
					stmt.close();
				if (rs != null)
					rs.close();
				if (conn != null)
					conn.close();
			} catch (SQLException e1) {
				// TODO Auto-generated catch block
				e1.printStackTrace();
			}
		}

		return list1;
	}

	
	

}
