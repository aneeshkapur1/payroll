package com.payroll.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import com.payroll.exceptions.PayrollException;
import com.payroll.model.Address;
import com.payroll.model.Department;
import com.payroll.model.Employee;
import com.payroll.model.EmployeeSkillSet;
import com.payroll.model.skills;
import com.payroll.services.AddressService;
import com.payroll.services.EmployeeService;
import com.payroll.services.SkillSetService;
import com.payroll.util.ConnectionUtil;

public class EmployeeDAO {
	
	
	public boolean deleteEmployee(Connection connObj, int empId) throws PayrollException {

		boolean flag = false;
		

		String query = "delete from EMPLOYEE where emp_id=?";
		// Connection connObj = null;
		PreparedStatement pstmt = null;
		ResultSet result = null;

		try {
			
			pstmt = connObj.prepareStatement(query);
			pstmt.setInt(1, empId);
			
			result = pstmt.executeQuery();
			
		flag = true;
			
			
			
			

		} catch (SQLException e) {

			throw new PayrollException("Employee DAO has problem" + e);

		} finally {
			try {
				if (result != null) {
					result.close();
				}

				if (pstmt != null) {
					pstmt.close();
				}

				/*
				 * if (connObj != null) { connObj.close(); }
				 */
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				throw new PayrollException("Error while closing Object" + e);

			}
		}
		return flag;

	}
	
	public int updateEmployee(Connection connObj, Employee employee) throws PayrollException {

		int count = 0;
		

		boolean flag = false;
		String query = "update EMPLOYEE set "
				+ " emp_name=?,emp_salary=?,fk_dept_id=? where emp_id=?";
		// Connection connObj = null;
		PreparedStatement pstmt = null;
		ResultSet result = null;

		try {
			// emp
			pstmt = connObj.prepareStatement(query);
			pstmt.setString(1, employee.getEmpName());
			pstmt.setDouble(2, employee.getEmpSalary());
			pstmt.setInt(3, employee.getDepartment().getDepartmentId());
			pstmt.setInt(4, employee.getEmpId());

			count =pstmt.executeUpdate();
			
			

		} catch (SQLException e) {

			throw new PayrollException("Employee DAO has problem" + e);

		} finally {
			try {
				if (result != null) {
					result.close();
				}

				if (pstmt != null) {
					pstmt.close();
				}

				/*
				 * if (connObj != null) { connObj.close(); }
				 */
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				throw new PayrollException("Error while closing Object" + e);

			}
		}

		return count;

	}
	
	
	public Employee fetchEmployeeById(int empId) throws PayrollException
	{
		boolean flag = false;
		String query = "select e.*,d.*,a.*, s.*" 
				+ " from department d inner join " 
				+ "employee e inner join "
				+ "emp_address a inner join " + "skills s inner join emp_skillset es on"
				+ " d.dept_id=e.fk_dept_id and "
				+ "e.fk_address_id=a.address_id and" + " s.skill_id=es.fk_skill_id and" + 
				" e.emp_id=es.fk_emp_id"
				+ " where e.emp_id=?";
		Connection conn = null;
		PreparedStatement stmt = null;
		ResultSet rs = null;
		Employee employee = null;
		try
		{
			conn= ConnectionUtil.getConnection();
			if(empId == 0)
			{
				throw new PayrollException("EmpId is zero");
			}
			else
			{
			stmt = conn.prepareStatement(query);
			stmt.setInt(1,empId);
			}
			rs = stmt.executeQuery();
			List<skills> list = new ArrayList<skills>();
			String skillStr=null;
			while(rs.next())
			{
				int eid=rs.getInt("emp_Id");
				String name=rs.getString("emp_name");
				Double salary=rs.getDouble("emp_salary");
				
				int deptId=rs.getInt("dept_id");
				String deptName=rs.getString("dept_name");
				String deptLocation=rs.getString("dept_location");
				
				Department dept=new Department(deptId,deptName,deptLocation);
				
				int addressId=rs.getInt("address_id");
				String street=rs.getString("street");
				String city=rs.getString("city");
				String state=rs.getString("state");
				String country=rs.getString("country");
				
				int skillId = rs.getInt("skill_id");
				String skillName = rs.getString("skill_name");
				 skillStr+=skillName;
				skills skills= new skills(skillId,skillName);
				list.add(skills);
				
				Address ad=new Address(addressId,street,city,state,country);
				
				employee=new Employee(eid,name,salary);
				employee.setAddress(ad);
				employee.setDepartment(dept);
				System.out.println(employee);
			
			}
			
			employee.setSkillsList(list);
			employee.setSkillStr(skillStr);

		} catch (SQLException e) {
			System.out.println(e.getMessage());
		} finally {
			try {
				if (stmt != null)
					stmt.close();
				if (rs != null)
					rs.close();
				if (conn != null)
					conn.close();
			} catch (SQLException e1) {
				// TODO Auto-generated catch block
				e1.printStackTrace();
			}
		}
		
		return employee;

		}
	
	
	
	public List<Employee> fetchAllData(String searchname) {
		
		List<Employee> list = new ArrayList<Employee>();
		String query = "select e.emp_id,e.emp_name,e.emp_salary,d.dept_id,d.dept_name,"
				+ "d.dept_location,a.address_id,a.street,a.city,a.state,a.country,"
				+ " group_concat(s.skill_name) from department d inner join " 
				+ "employee e inner join "
				+ "emp_address a inner join " + "skills s inner join emp_skillset es on"
				+ " d.dept_id=e.fk_dept_id and "
				+ "e.fk_address_id=a.address_id and" + " s.skill_id=es.fk_skill_id and" + 
				" e.emp_id=es.fk_emp_id"
				+ " group by e.emp_id;";
		
		String queryByName = "select e.emp_id,e.emp_name,e.emp_salary,d.dept_id,d.dept_name,"
				+ "d.dept_location,a.address_id,a.street,a.city,a.state,a.country,"
				+ " group_concat(s.skill_name) from department d inner join " 
				+ "employee e inner join "
				+ "emp_address a inner join " + "skills s inner join emp_skillset es on"
				+ " d.dept_id=e.fk_dept_id and "
				+ "e.fk_address_id=a.address_id and" + " s.skill_id=es.fk_skill_id and" + 
				" e.emp_id=es.fk_emp_id"
				+ " where e.emp_name like ? group by e.emp_id;";
		
		
		Connection conn = null;
		PreparedStatement stmt = null;
		ResultSet rs = null;
		try {
			conn = ConnectionUtil.getConnection();
			if(searchname==null)
			{
				stmt=conn.prepareStatement(query);
			}
			else
			{
				stmt=conn.prepareStatement(queryByName);
				stmt.setString(1, "%"+searchname+"%");
			}
			
			
			rs=stmt.executeQuery();
			
			while(rs.next())
			{
				int empId=rs.getInt("emp_id");
				String name=rs.getString(2);
				Double salary=rs.getDouble(3);
				
				int deptId=rs.getInt(4);
				String deptName=rs.getString(5);
				String deptLocation=rs.getString(6);
				
				Department dept=new Department(deptId,deptName,deptLocation);
				
				int addressId=rs.getInt(7);
				String street=rs.getString(8);
				String city=rs.getString(9);
				String state=rs.getString(10);
				String country=rs.getString(11);
				
				String skills=rs.getString(12);
				
				Address ad=new Address(addressId,street,city,state,country);
				
				Employee employee=new Employee(empId,name,salary,dept,ad,skills);
				list.add(employee);
			}

		} catch (SQLException e) {
			System.out.println(e.getMessage());
		} finally {
			try {
				if (stmt != null)
					stmt.close();
				if (rs != null)
					rs.close();
				if (conn != null)
					conn.close();
			} catch (SQLException e1) {
				// TODO Auto-generated catch block
				e1.printStackTrace();
			}
		}

		return list;
	}

	
	

	public int registerEmployee(Connection connObj, Employee e) throws SQLException, PayrollException
	{
		
		
		//employee
		String query = "Insert into employee(emp_name,emp_salary,fk_dept_id,fk_address_id) values(?,?,?,?)";
		PreparedStatement pstmt = null;
		ResultSet result = null;
		int count = 0;
		int generatedId = 0;
		
		try{
			
		
			pstmt = connObj.prepareStatement(query);
			pstmt.setString(1,e.getEmpName());
			pstmt.setDouble(2, e.getEmpSalary());
			pstmt.setInt(3, e.getDepartment().getDepartmentId());
			pstmt.setInt(4, e.getAddress().getAddressId());
			
			
			count = pstmt.executeUpdate();
				result = pstmt.getGeneratedKeys();
			if(result.next())
			{
				generatedId = result.getInt(1);
			}
		}
//	
		catch(SQLException s)
		{
		
		s.printStackTrace();
		throw new PayrollException("connection or query problem" + s);
	}
	catch(Exception o)
	{
		System.out.println("Exception");
		throw new PayrollException("connection or query problem" + o);
		
	}finally
	{
		
		if(pstmt != null)
		{
			try
			{
				pstmt.close();
				
			}
			catch(SQLException o)
			{
				o.printStackTrace();
				throw new PayrollException("connection or query problem" + o);
			}
		}
		
	}
	
return generatedId;
}
	public int DeleteEmployee(Connection connObj, int empId) throws PayrollException {
		int count = 0;
		String query = "delete from employee where emp_id=?";

		// Connection connObj = null;
		PreparedStatement pstmt = null;
		ResultSet result = null;

		try {
			// connObj = ConnectionUtil.getConnection();
			pstmt = connObj.prepareStatement(query);
			pstmt.setInt(1,empId);
			
			count=pstmt.executeUpdate();


		} catch (SQLException e) {
			// TODO Auto-generated catch block
			String message = "Error while deleting Employee data." + e;
			throw new PayrollException(message);
		} catch (Exception e) {
			String message = "Error while deleting Employee data." + e;
			throw new PayrollException(message);
		} finally {

			try {
				if (pstmt != null)
					pstmt.close();
				if (result != null)
					result.close();
				/*
				 * if (connObj != null) connObj.close();
				 */
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				String message = "Error while closing objects." + e;
				throw new PayrollException(message);
			}

		}
		return count;
	}

	public String	updateWholeEmp(Employee employee,String[] skills)throws PayrollException{
		
		String message="";
		Connection connObj=null;
		try {
			EmployeeService employeeDAO=new EmployeeService();
			connObj=ConnectionUtil.getConnection();
			connObj.setAutoCommit(false);
			
			employeeDAO.updateEmployee(connObj, employee);
			
			
			AddressService addressDAO=new AddressService();
			addressDAO.updateAddress(connObj, employee.getAddress());
			
			SkillSetService dao=new SkillSetService();
			dao.removeSkillSet(connObj, employee.getEmpId());
			
			for (String skillId:skills) {
				
				EmployeeSkillSet skillSet=new EmployeeSkillSet();
				skillSet.setEmpskillSetId(Integer.parseInt(skillId));
				skillSet.setEmployee(employee);
				dao.registerSkillSet(connObj, skillSet);
			}
			
			
			//PrintWriter out=response.getWriter();
			connObj.commit();
			System.out.print("Updated successfully");
			
			message="Updated successfully";
	} catch (PayrollException e) {
		// TODO Auto-generated catch block
		try {
			connObj.rollback();
		} catch (SQLException e1) {
			// TODO Auto-generated catch block
			throw new PayrollException("Rollback "+e1.getMessage());
			//e1.printStackTrace();
		}
		e.printStackTrace();
		throw new PayrollException("Rollback update  "+e.getMessage());
		
	} catch (SQLException e) {
		// TODO Auto-generated catch block
		try {
			connObj.rollback();
		} catch (SQLException e1) {
			// TODO Auto-generated catch block
			e1.printStackTrace();
			throw new PayrollException("Rollback "+e1.getMessage());
			
		}
		
		e.printStackTrace();
		
		
	}


	return message;

			
			
			
		}
		
		
	public String  saveWholeEmp(Employee employee ,String[] skills)throws PayrollException{
		Connection connObj = null;
		String message="";
		try {
			connObj = ConnectionUtil.getConnection();
			connObj.setAutoCommit(false);

			AddressService addressDAO = new AddressService();
			int addressId = addressDAO.registerAddress(connObj, employee.getAddress());
			employee.getAddress().setAddressId(addressId);
			//employee.setAddress(address);
			//employee.getDepartment().setDepartment(department);

			EmployeeService dao = new EmployeeService();
			int empId = dao.registerEmployee(connObj, employee);
			employee.setEmpId(empId);

			SkillSetService skillSetdao = new SkillSetService();

			for (String string : skills) {

				int skillId = Integer.parseInt(string);
				EmployeeSkillSet employeeSkillSet = new EmployeeSkillSet();
				employeeSkillSet.setEmpskillSetId(skillId);
				skills skils = new skills();
				skils.setSkillId(skillId);

				employeeSkillSet.setSkills(skils);
				employeeSkillSet.setEmployee(employee);
				skillSetdao.registerSkillSet(connObj, employeeSkillSet);
				connObj.commit();

			}
			connObj.commit();

			if (empId != 0) {
				message="You are empid is " + empId;
				System.out.print("You are empid is " + empId);
				System.out.println("Please remember for future ");

			}

		} catch (SQLException e) {
			// TODO Auto-generated catch block

			try {
				connObj.rollback();
			} catch (SQLException e1) {
				// TODO Auto-generated catch block
				throw new PayrollException("Error while roll back");
			}
			e.printStackTrace();

		} catch (PayrollException e) {
			// TODO Auto-generated catch block
			try {
				connObj.rollback();
			} catch (SQLException e1) {
				// TODO Auto-generated catch block
				throw new PayrollException("Error while roll back");
			}
			e.printStackTrace();
		} finally {

			try {
				connObj.close();
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				throw new PayrollException("Error while closing connection");
				
				//e.printStackTrace();
			}

		}
		return message;

		
		
	}
		
		
		

}
