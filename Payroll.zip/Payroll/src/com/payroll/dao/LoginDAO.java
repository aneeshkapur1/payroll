package com.payroll.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import com.payroll.exceptions.PayrollException;
import com.payroll.model.LoginDetails;
import com.payroll.util.ConnectionUtil;

public class LoginDAO {
	
	public boolean loginCheck( LoginDetails loginDetails) throws PayrollException
	{
		boolean flag = false;
		String query = "select * from login where username = ? and password = ?";
		PreparedStatement pstmt = null;
		ResultSet result = null;
		Connection connObj = null;
		try{
			connObj = ConnectionUtil.getConnection();
		pstmt = connObj.prepareStatement(query);
		pstmt.setString(1, loginDetails.getUsername());
		pstmt.setString(2, loginDetails.getPassword());
		
		result = pstmt.executeQuery();
		if(result.next())
		{
			flag = true;
		}
		}
		catch(SQLException s)
		{
			s.printStackTrace();
			throw new PayrollException("connection or query problem" + s);
		}
		catch(Exception e)
		{
			System.out.println("Exception");
			throw new PayrollException("connection or query problem" + e);
			
		}
		finally
		{
			if(result !=  null)
				
			{
				
				try
				{
					result.close();
					
				}
				catch(SQLException e)
				{
					e.printStackTrace();
				}
			}
			
			
			if(pstmt != null)
			{
				try
				{
					pstmt.close();
					
				}
				catch(SQLException e)
				{
					e.printStackTrace();
					throw new PayrollException("connection or query problem" + e);
				}
			}
			
		}
		return flag;
		}

}
