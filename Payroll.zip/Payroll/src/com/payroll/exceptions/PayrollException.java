package com.payroll.exceptions;

public class PayrollException extends Exception {
	
	private String message;
	
	

	public PayrollException(String message) {
		super(message);
		
	}



	@Override
	public String toString() {
		return "PayrollException [message=" + message + "]";
	}

}
