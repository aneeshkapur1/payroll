package com.payroll.services;

import com.payroll.dao.LoginDAO;
import com.payroll.exceptions.PayrollException;
import com.payroll.model.LoginDetails;

public class LoginService implements ILogin {
	LoginDAO loginDAO=new LoginDAO();

	public LoginService() {
		// TODO Auto-generated constructor stub
	}

	@Override
	public boolean loginCheck(LoginDetails loginDetails) throws PayrollException {
		// TODO Auto-generated method stub
		return loginDAO.loginCheck(loginDetails);
	}

}
