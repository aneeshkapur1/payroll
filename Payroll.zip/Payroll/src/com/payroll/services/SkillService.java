package com.payroll.services;

import java.sql.SQLException;
import java.util.List;

import com.payroll.dao.SkillDAO;
import com.payroll.exceptions.PayrollException;

import com.payroll.model.skills;

public class SkillService implements ISkill {

	SkillDAO skillDAO=new SkillDAO();
	public SkillService() {
		// TODO Auto-generated constructor stub
	}

	@Override
	public int registerSkill(skills skills) throws PayrollException {
		// TODO Auto-generated method stub
		try {
			return skillDAO.registerSkills(skills);
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return 0;
	}

	@Override
	public List<skills> fetchAllSkills() throws PayrollException {
		// TODO Auto-generated method stub
		return skillDAO.fetchSkills();
	}

}
