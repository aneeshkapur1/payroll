package com.payroll.services;

import java.sql.Connection;
import java.sql.SQLException;
import java.util.List;

import com.payroll.dao.EmployeeDAO;
import com.payroll.exceptions.PayrollException;
import com.payroll.model.Employee;

public class EmployeeService implements IEmployee {

	
	EmployeeDAO employeeDAO=new EmployeeDAO();
	public EmployeeService() {
		// TODO Auto-generated constructor stub
	}

	@Override
	public List<Employee> fetchAllData(String name) throws PayrollException {
		// TODO Auto-generated method stub
		return employeeDAO.fetchAllData(name);
	}

	@Override
	public Employee fetchEmployeeById(int empId) throws PayrollException {
		// TODO Auto-generated method stub
		return employeeDAO.fetchEmployeeById(empId);
	}

	@Override
	public int registerEmployee(Connection connObj, Employee employee) throws PayrollException {
		// TODO Auto-generated method stub
		try {
			return employeeDAO.registerEmployee(connObj, employee);
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return 0;
	}

	@Override
	public int updateEmployee(Connection connObj, Employee employee) throws PayrollException {
		// TODO Auto-generated method stub
		return employeeDAO.updateEmployee(connObj, employee);
	}
	public int DeleteEmployee(Connection connObj, int empId) throws PayrollException 
	{
		return employeeDAO.DeleteEmployee(connObj, empId);
	}
	
	public String saveWholeEmp(Employee employee, String[] skills) throws PayrollException
	{
		return employeeDAO.saveWholeEmp(employee, skills);
		
	}

	public String updateWholeEmp(Employee employee, String[] skills) throws PayrollException {
		// TODO Auto-generated method stub
		return employeeDAO.updateWholeEmp(employee, skills);
	}

}
