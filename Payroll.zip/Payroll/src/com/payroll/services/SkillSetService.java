package com.payroll.services;

import java.sql.Connection;
import java.sql.SQLException;

import com.payroll.dao.SkillSetDao;
import com.payroll.exceptions.PayrollException;
import com.payroll.model.EmployeeSkillSet;

public class SkillSetService implements ISkillSet {

	SkillSetDao employeeSkillSetDAO=new SkillSetDao();
	
	public SkillSetService() {
		// TODO Auto-generated constructor stub
	}

	@Override
	public int registerSkillSet(Connection connObj, EmployeeSkillSet skillSet) throws PayrollException {
		// TODO Auto-generated method stub
		try {
			return employeeSkillSetDAO.registerSkillSet(connObj, skillSet);
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return 0;
	}

	@Override
	public int removeSkillSet(Connection connObj, int empId) throws PayrollException {
		// TODO Auto-generated method stub
		return employeeSkillSetDAO.removeSkillSet(connObj, empId);
	}

}
