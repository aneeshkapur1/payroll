package com.payroll.services;

import java.util.List;

import com.payroll.exceptions.PayrollException;

import com.payroll.model.skills;

public interface ISkill {
	public int registerSkill(skills skills) throws PayrollException;
	public List<skills> fetchAllSkills() throws PayrollException ;

		
}
