package com.payroll.model;

public class EmployeeSkillSet {
	
	private int empskillSetId;
	private skills skills;
	private Employee Employee;
	public int getEmpskillSetId() {
		return empskillSetId;
	}
	public void setEmpskillSetId(int empskillSetId) {
		this.empskillSetId = empskillSetId;
	}
	public skills getSkills() {
		return skills;
	}
	public void setSkills(skills skills) {
		this.skills = skills;
	}
	public Employee getEmployee() {
		return Employee;
	}
	public void setEmployee(Employee employee) {
		Employee = employee;
	}
	@Override
	public String toString() {
		return "EmployeeSkillSet [empskillSetId=" + empskillSetId + ", skills=" + skills + ", Employee=" + Employee
				+ "]";
	}
	public EmployeeSkillSet(int empskillSetId, com.payroll.model.skills skills, com.payroll.model.Employee employee) {
		super();
		this.empskillSetId = empskillSetId;
		this.skills = skills;
		Employee = employee;
	}
	public EmployeeSkillSet() {
		// TODO Auto-generated constructor stub
	}
	
	

}
