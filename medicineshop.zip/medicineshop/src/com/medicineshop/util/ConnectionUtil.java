package com.medicineshop.util;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;

import com.medicineshop.exception.MedicineShopException;
import com.mysql.jdbc.Driver;

public class ConnectionUtil {

	public ConnectionUtil() {
		// TODO Auto-generated constructor stub
	}
	
	public static Connection getConnection() throws MedicineShopException
	{
		Connection connObj = null;
		
		
		try {
			DriverManager.registerDriver(new Driver());
			connObj=DriverManager.getConnection("jdbc:mysql://localhost/medicine_shop","root","root");
		
		if(connObj==null)
			System.out.println("Not connected");
		else
			System.out.println("Connected");
		
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			throw new MedicineShopException("Error in connection");
		}
		
		return connObj;
		
	}

}
