package com.medicineshop.model;

import java.sql.Date;

import java.util.ArrayList;
import java.util.List;

public class Bills {
	
	private int billId;
	private Date billDate;
	private PatientDetails patientDetails;
	private float totalAmount;
	private float totalCostPrice;
	private List<Medicine> medicineList=new ArrayList<Medicine>();

	public Bills() {
		// TODO Auto-generated constructor stub
	}

	
	public Bills(int billId, Date billDate,float totalAmount,float totalCostPrice,PatientDetails patientDetails) {
		super();
		this.billId = billId;
		this.billDate = billDate;
		this.totalCostPrice = totalCostPrice;
		this.totalAmount = totalAmount;
		this.patientDetails=patientDetails;
	}

	public int getBillId() {
		return billId;
	}

	public void setBillId(int billId) {
		this.billId = billId;
	}

	public Date getBillDate() {
		return billDate;
	}

	public void setBillDate(Date billDate) {
		this.billDate = billDate;
	}

	public PatientDetails getPatientDetails() {
		return patientDetails;
	}

	public void setPatientDetails(PatientDetails patientDetails) {
		this.patientDetails = patientDetails;
	}

	public List<Medicine> getMedicineList() {
		return medicineList;
	}

	public void setMedicineList(List<Medicine> medicineList) {
		this.medicineList = medicineList;
	}

	public float getTotalAmount() {
		return totalAmount;
	}

	public void setTotalAmount(float totalAmount) {
		this.totalAmount = totalAmount;
	}

	public float getTotalCostPrice() {
		return totalCostPrice;
	}

	public void setTotalCostPrice(float totalCostPrice) {
		this.totalCostPrice = totalCostPrice;
	}

	@Override
	public String toString() {
		return "Bills [billId=" + billId + ", billDate=" + billDate + ", patientDetails=" + patientDetails
				+ ", medicineList=" + medicineList + "]";
	}
	
	

}
