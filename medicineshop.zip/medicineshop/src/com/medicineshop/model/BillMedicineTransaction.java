package com.medicineshop.model;

import java.sql.Date;

public class BillMedicineTransaction {
	
	private int transactionID;
	private Date transactionDate;
	private Medicine medicine;
	private Bills bill;
	private int quantity;

	public BillMedicineTransaction() {
		// TODO Auto-generated constructor stub
	}

	public BillMedicineTransaction(  Medicine medicine, Bills bill,int quantity) {
		super();
		this.transactionDate =bill.getBillDate() ;
		this.medicine = medicine;
		this.bill = bill;
		this.quantity = quantity;
	}

	public int getTransactionID() {
		return transactionID;
	}

	public void setTransactionID(int transactionID) {
		this.transactionID = transactionID;
	}

	public Date getTransactionDate() {
		return transactionDate;
	}

	public void setTransactionDate(Date transactionDate) {
		this.transactionDate = transactionDate;
	}

	public Medicine getMedicine() {
		return medicine;
	}

	public void setMedicine(Medicine medicine) {
		this.medicine = medicine;
	}

	public Bills getBill() {
		return bill;
	}

	public void setBill(Bills bill) {
		this.bill = bill;
	}

	public int getQuantity() {
		return quantity;
	}

	public void setQuantity(int quantity) {
		this.quantity = quantity;
	}

	@Override
	public String toString() {
		return "BillMedicineTransaction [transactionID=" + transactionID + ", transactionDate=" + transactionDate
				+ ", medicine=" + medicine + ", bill=" + bill + ", quantity=" + quantity + "]";
	}
	
	

}
