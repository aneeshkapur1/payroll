package com.medicineshop.model;

public class MedicineType {
	
	private int medicineTypeId;
	private String medicineType;

	public MedicineType() {
		// TODO Auto-generated constructor stub
	}

	public MedicineType(int medicineTypeId, String medicineType) {
		super();
		this.medicineTypeId = medicineTypeId;
		this.medicineType = medicineType;
	}

	public int getMedicineTypeId() {
		return medicineTypeId;
	}

	public void setMedicineTypeId(int medicineTypeId) {
		this.medicineTypeId = medicineTypeId;
	}

	public String getMedicineType() {
		return medicineType;
	}

	public void setMedicineType(String medicineType) {
		this.medicineType = medicineType;
	}

	@Override
	public String toString() {
		return "MedicineType [medicineTypeId=" + medicineTypeId + ", medicineType=" + medicineType + "]";
	}
	

}
