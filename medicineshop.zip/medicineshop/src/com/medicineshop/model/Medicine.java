package com.medicineshop.model;

public class Medicine {
	
	private int medicineId;
	private String medicineName;
	private int itemsPerStrip;
	private float buyingPrice;
	private float sellingPrice;
	private MedicineType medicineType;

	public Medicine() {
		// TODO Auto-generated constructor stub
	}

	public Medicine( String medicineName, int itemsPerStrip, float buyingPrice, float sellingPrice,
			MedicineType medicineType) {
		super();
		
		this.medicineName = medicineName;
		this.itemsPerStrip = itemsPerStrip;
		this.buyingPrice = buyingPrice;
		this.sellingPrice = sellingPrice;
		this.medicineType = medicineType;
	}
	
	public Medicine( String medicineName, int itemsPerStrip, float buyingPrice, float sellingPrice) {
		this.medicineName = medicineName;
		this.itemsPerStrip = itemsPerStrip;
		this.buyingPrice = buyingPrice;
		this.sellingPrice = sellingPrice;
		
	}

	public int getMedicineId() {
		return medicineId;
	}

	public void setMedicineId(int medicineId) {
		this.medicineId = medicineId;
	}

	public String getMedicineName() {
		return medicineName;
	}

	public void setMedicineName(String medicineName) {
		this.medicineName = medicineName;
	}

	public int getItemsPerStrip() {
		return itemsPerStrip;
	}

	public void setItemsPerStrip(int itemsPerStrip) {
		this.itemsPerStrip = itemsPerStrip;
	}

	public float getBuyingPrice() {
		return buyingPrice;
	}

	public void setBuyingPrice(float buyingPrice) {
		this.buyingPrice = buyingPrice;
	}

	public float getSellingPrice() {
		return sellingPrice;
	}

	public void setSellingPrice(float sellingPrice) {
		this.sellingPrice = sellingPrice;
	}

	public MedicineType getMedicineType() {
		return medicineType;
	}

	public void setMedicineType(MedicineType medicineType) {
		this.medicineType = medicineType;
	}

	@Override
	public String toString() {
		return "medicine [medicineId=" + medicineId + ", medicineName=" + medicineName + ", itemsPerStrip="
				+ itemsPerStrip + ", buyingPrice=" + buyingPrice + ", sellingPrice=" + sellingPrice + ", medicineType="
				+ medicineType + "]";
	}
	
	
	

}
