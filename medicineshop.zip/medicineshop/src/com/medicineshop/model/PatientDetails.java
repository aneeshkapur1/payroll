package com.medicineshop.model;

public class PatientDetails {
	
	private int patientId;
	private String patientName;
	private String doctorName;
	private int age;
	private String gender;
	private String email;

	public PatientDetails() {
		// TODO Auto-generated constructor stub
	}

	

	public PatientDetails(int patientId, String patientName, String doctorName, int age, String gender, String email) {
		super();
		this.patientId = patientId;
		this.patientName = patientName;
		this.doctorName = doctorName;
		this.age = age;
		this.gender = gender;
		this.email = email;
	}
	public PatientDetails( String patientName, String doctorName, int age, String gender, String email) {

		this.patientName = patientName;
		this.doctorName = doctorName;
		this.age = age;
		this.gender = gender;
		this.email = email;
	}
	public PatientDetails(int patientId, String patientName, String doctorName) {

		this.patientId = patientId;
		this.patientName = patientName;
		this.doctorName = doctorName;
	}


	
	public int getAge() {
		return age;
	}



	public void setAge(int age) {
		this.age = age;
	}



	public String getGender() {
		return gender;
	}



	public void setGender(String gender) {
		this.gender = gender;
	}



	public String getEmail() {
		return email;
	}



	public void setEmail(String email) {
		this.email = email;
	}



	public int getPatientId() {
		return patientId;
	}

	public void setPatientId(int patientId) {
		this.patientId = patientId;
	}

	public String getPatientName() {
		return patientName;
	}

	public void setPatientName(String patientName) {
		this.patientName = patientName;
	}

	public String getDoctorName() {
		return doctorName;
	}

	public void setDoctorName(String doctorName) {
		this.doctorName = doctorName;
	}

	@Override
	public String toString() {
		return "PatientDetails [patientId=" + patientId + ", patientName=" + patientName + ", doctorName=" + doctorName
				+ "]";
	}
	
	

}
