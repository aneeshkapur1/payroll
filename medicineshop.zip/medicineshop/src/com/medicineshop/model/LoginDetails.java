package com.medicineshop.model;

public class LoginDetails {
	
	private int adminId;
	private String adminName;
	private String password;
	private String email;

	public LoginDetails() {
		// TODO Auto-generated constructor stub
	}

	public LoginDetails( String adminName, String password, String email) {
		
		this.adminName = adminName;
		this.email = email;
		this.password= password;
	}
	public LoginDetails(  String email,String password) {
		this.email = email;
		this.password= password;
	}

	public int getAdminId() {
		return adminId;
	}

	public void setAdminId(int adminId) {
		this.adminId = adminId;
	}

	public String getAdminName() {
		return adminName;
	}

	public void setAdminName(String adminName) {
		this.adminName = adminName;
	}
	
	public String getPassword() {
		return password;
	}

	public void setPassword(String password) {
		this.password = password;
	}

	public String getEmail() {
		return email;
	}

	public void setEmail(String email) {
		this.email = email;
	}

	@Override
	public String toString() {
		return "LoginDetails [adminId=" + adminId + ", adminName=" + adminName + ", email=" + email + "]";
	}
	
	

}
