package com.medicineshop.controller;

import java.io.IOException;
import java.sql.Connection;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.medicineshop.dao.MedicineDao;
import com.medicineshop.exception.MedicineShopException;
import com.medicineshop.util.ConnectionUtil;


/**
 * Servlet implementation class RemoveMedicineServlet
 */
@WebServlet("/RemoveMedicineServlet")
public class RemoveMedicineServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public RemoveMedicineServlet() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		response.getWriter().append("Served at: ").append(request.getContextPath());
		
		int medId=Integer.parseInt(request.getParameter("medId"));
		Connection connObj=null;
		try {
			connObj=ConnectionUtil.getConnection();
			
			MedicineDao medicineDao=new MedicineDao();
			
			medicineDao.deleteMedicine(medId,connObj);
			request.getRequestDispatcher("Home.jsp").forward(request, response);
			
			
		} catch (MedicineShopException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
	}

}
