package com.medicineshop.controller;

import java.io.IOException;
import java.sql.Connection;
import java.util.List;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.medicineshop.dao.MedicineDao;
import com.medicineshop.dao.MedicineTypeDao;
import com.medicineshop.exception.MedicineShopException;
import com.medicineshop.model.Medicine;
import com.medicineshop.model.MedicineType;
import com.medicineshop.util.ConnectionUtil;

/**
 * Servlet implementation class SearchMedicineByIDServlet
 */
@WebServlet("/SearchMedicineByIDServlet")
public class SearchMedicineByIDServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public SearchMedicineByIDServlet() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		response.getWriter().append("Served at: ").append(request.getContextPath());
		
		Connection connObj=null;
		
		int medId=Integer.parseInt(request.getParameter("medId"));
		
		try {
			connObj=ConnectionUtil.getConnection();
			MedicineDao medicineDao=new MedicineDao();
			Medicine med=medicineDao.searchMedicineById(medId, connObj);
			
			
			MedicineTypeDao medicineTypeDao=new MedicineTypeDao();
			List<MedicineType> typeList=medicineTypeDao.searchAllTypeList(connObj);
			
			request.setAttribute("medicine", med);
			request.setAttribute("medicineType", typeList);
			request.getRequestDispatcher("UpdateMedicine1.jsp").forward(request, response);
			
			
		} catch (MedicineShopException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

}
