package com.medicineshop.controller;

import java.io.IOException;

import java.sql.Connection;
import java.util.List;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.medicineshop.dao.MedicineDao;
import com.medicineshop.exception.MedicineShopException;
import com.medicineshop.model.Medicine;
import com.medicineshop.util.ConnectionUtil;

/**
 * Servlet implementation class SearchMedicineServlet
 */
@WebServlet("/SearchMedicineServlet")
public class SearchMedicineServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public SearchMedicineServlet() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		
		String medName=request.getParameter("medName");
		String flag=request.getParameter("flag");
		
		Connection connObj=null;
		
		
		try {
			connObj=ConnectionUtil.getConnection();
			
			MedicineDao medicineDao=new MedicineDao();
			List<Medicine> med=medicineDao.searchMedicineByName(medName, connObj);
			
			request.setAttribute("search", med);
			
			if(flag.equals("false"))
			request.getRequestDispatcher("Search.jsp").forward(request, response);
			else if(flag.equals("false"))
				request.getRequestDispatcher("Search2.jsp").forward(request, response);	
			else
				request.getRequestDispatcher("SearchToUpdate.jsp").forward(request, response);	
			
		} catch (MedicineShopException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

}
