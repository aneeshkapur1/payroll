package com.medicineshop.controller;

import java.io.IOException;
import java.sql.Connection;
import java.sql.SQLException;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.medicineshop.dao.BillMedicineTransactionDao;
import com.medicineshop.dao.BillsDao;
import com.medicineshop.dao.MedicineDao;
import com.medicineshop.exception.MedicineShopException;
import com.medicineshop.model.BillMedicineTransaction;
import com.medicineshop.model.Bills;
import com.medicineshop.model.Medicine;
import com.medicineshop.util.ConnectionUtil;

/**
 * Servlet implementation class AddToCartServlet
 */
@WebServlet("/AddToCartServlet")
public class AddToCartServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public AddToCartServlet() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		
		
		int quantity=Integer.parseInt(request.getParameter("quantity"));
		
		int medId=Integer.parseInt(request.getParameter("medId"));
		
		Connection connObj=null;
		HttpSession session=request.getSession();
		
		
		
		
		try {
			
			connObj=ConnectionUtil.getConnection();
			
			connObj.setAutoCommit(false);
			MedicineDao medicineDao=new MedicineDao();
			Medicine med= medicineDao.searchMedicineById(medId, connObj);
			
			System.out.println(session.getAttribute("billId"));
			
			int bId=(int) session.getAttribute("billId");
			
			BillsDao billDao=new BillsDao();
			Bills bill=billDao.searchBillById(bId, connObj);
			
			BillMedicineTransactionDao transaction=new BillMedicineTransactionDao();
			
			BillMedicineTransaction trans=new BillMedicineTransaction(med, bill, quantity);
			
			int tId=transaction.registerBillMedicineTransaction(med, bill, quantity, connObj);
			trans.setTransactionID(tId);
			
			
			connObj.commit();
			
			response.sendRedirect("Search.jsp");
			
		} catch (MedicineShopException | SQLException e) {
			// TODO Auto-generated catch block
			try {
				connObj.rollback();
			} catch (SQLException e1) {
				// TODO Auto-generated catch block
				e1.printStackTrace();
			}
			e.printStackTrace();
		}
		
		
	}

}
