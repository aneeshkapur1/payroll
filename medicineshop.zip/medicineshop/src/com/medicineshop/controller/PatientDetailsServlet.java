package com.medicineshop.controller;

import java.io.IOException;
import java.sql.Connection;
import java.sql.Date;
import java.sql.SQLException;
import java.time.LocalDate;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.medicineshop.dao.BillsDao;
import com.medicineshop.dao.PatientDetailsDao;
import com.medicineshop.exception.MedicineShopException;
import com.medicineshop.model.Bills;
import com.medicineshop.model.PatientDetails;
import com.medicineshop.util.ConnectionUtil;

/**
 * Servlet implementation class PatientDetailsServlet
 */
@WebServlet("/PatientDetailsServlet")
public class PatientDetailsServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public PatientDetailsServlet() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		
		Connection connObj = null;
			try {
				connObj = ConnectionUtil.getConnection();
				
				connObj.setAutoCommit(false);
				
				String pName=request.getParameter("pname");
				String dName=request.getParameter("dname");
				int age=Integer.parseInt(request.getParameter("age"));
				String gender=request.getParameter("gender");
				String email=request.getParameter("email");
				
				PatientDetails patient=new PatientDetails( pName, dName, age, gender, email);
				
				PatientDetailsDao patientDao=new PatientDetailsDao(); 
				
				PatientDetails p1=patientDao.searchPatient(patient, connObj);
				
				int pId;
				
				if(p1==null)
				{
				
				pId=patientDao.registerPatientDetails(patient, connObj);
				patient.setPatientId(pId);
				}
				else
				{
				pId=p1.getPatientId();
				patient.setPatientId(pId);
				}
					
				System.out.println("Patient"+pId);
				Bills bill=new Bills();
				LocalDate dt=LocalDate.now();
				Date billDate=Date.valueOf(dt);
				
				bill.setBillDate(billDate);
				bill.setPatientDetails(patient);
				bill.setTotalAmount(0);
				bill.setTotalCostPrice(0);
				
				BillsDao billDao=new BillsDao();
				int billId=billDao.registerBillDetails(bill, connObj);
				bill.setBillId(billId);
				
				HttpSession session=request.getSession();
				session.setAttribute("billId", billId);
				session.setAttribute("pId", pId);
				
				System.out.println("hello sessionID"+session.getAttribute("billId"));
				
				

				connObj.commit();
				
				
				
				
				
			} catch (MedicineShopException | SQLException e) {
				// TODO Auto-generated catch block
				
				try {
					connObj.rollback();
				} catch (SQLException e1) {
					// TODO Auto-generated catch block
					e1.printStackTrace();
				}
				e.printStackTrace();
			}
			
			request.getRequestDispatcher("Search.jsp").forward(request, response);
			
			

			
	}

}
