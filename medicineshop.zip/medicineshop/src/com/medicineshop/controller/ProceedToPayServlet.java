package com.medicineshop.controller;

import java.io.IOException;
import java.sql.Connection;
import java.util.Iterator;
import java.util.List;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.medicineshop.dao.BillMedicineTransactionDao;
import com.medicineshop.dao.BillsDao;
import com.medicineshop.exception.MedicineShopException;
import com.medicineshop.model.BillMedicineTransaction;
import com.medicineshop.model.Bills;
import com.medicineshop.util.ConnectionUtil;

/**
 * Servlet implementation class ProceedToPayServlet
 */
@WebServlet("/ProceedToPayServlet")
public class ProceedToPayServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public ProceedToPayServlet() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		response.getWriter().append("Served at: ").append(request.getContextPath());
		
		HttpSession session=request.getSession();
		int bId=(int) session.getAttribute("billId");
		
		Connection connObj=null;
		
		try {
			connObj=ConnectionUtil.getConnection();
			
			
			BillMedicineTransactionDao transaction=new BillMedicineTransactionDao();
			
			
			List<BillMedicineTransaction> transactionList=transaction.searchMedicineByBillId(bId, connObj);
			
			Iterator<BillMedicineTransaction> iter=transactionList.iterator();
			
			Bills bill=new Bills();
			
			while(iter.hasNext())
			{
				BillMedicineTransaction BMT=iter.next();
				
				if(BMT.getBill().getTotalAmount()>0)
				{
					bill.setBillId(BMT.getBill().getBillId());
					bill.setTotalAmount(BMT.getBill().getTotalAmount());
					bill.setTotalCostPrice(BMT.getBill().getTotalCostPrice());
				}
			}
			
			BillsDao billsDao=new BillsDao();
			
			billsDao.updateBillAmount(bill, connObj);
			
			session.invalidate();
			
			
			request.setAttribute("transaction", transactionList);
			request.getRequestDispatcher("GenerateBill.jsp").forward(request, response);
			
			
		} catch (MedicineShopException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
	}

}
