package com.medicineshop.controller;

import java.io.IOException;
import java.sql.Connection;
import java.util.List;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.medicineshop.dao.BillMedicineTransactionDao;
import com.medicineshop.dao.BillsDao;
import com.medicineshop.exception.MedicineShopException;
import com.medicineshop.model.BillMedicineTransaction;
import com.medicineshop.model.Bills;
import com.medicineshop.util.ConnectionUtil;

/**
 * Servlet implementation class TransactionServlet
 */
@WebServlet("/TransactionServlet")
public class TransactionServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public TransactionServlet() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		response.getWriter().append("Served at: ").append(request.getContextPath());
		
		Connection connObj=null;
		HttpSession session=request.getSession();
		
		int bId=(int) session.getAttribute("billId");
		
		try {
			connObj=ConnectionUtil.getConnection();
			
			BillMedicineTransactionDao transaction=new BillMedicineTransactionDao();
			
			
			List<BillMedicineTransaction> transactionList=transaction.searchMedicineByBillId(bId, connObj);
			
			BillsDao billDao=new BillsDao();
			
			Bills bill=billDao.searchBillById(bId, connObj);
			
			if(transactionList==null)
			{
				request.setAttribute("bill",bill);
			}
			else
			{
				request.setAttribute("transaction", transactionList);
			}
			
			
			request.getRequestDispatcher("MyCart.jsp").forward(request, response);
			
		} catch (MedicineShopException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		
		
		
	}

}
