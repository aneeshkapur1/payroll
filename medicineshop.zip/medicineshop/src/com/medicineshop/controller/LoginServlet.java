package com.medicineshop.controller;

import java.io.IOException;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.medicineshop.dao.LoginDetailsDao;
import com.medicineshop.exception.MedicineShopException;
import com.medicineshop.model.LoginDetails;

/**
 * Servlet implementation class LoginServlet
 */
@WebServlet("/LoginServlet")
public class LoginServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public LoginServlet() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		
		System.out.println("servlet post method");
		HttpSession session=request.getSession();
		String page="";

		String userName=request.getParameter("email");
		String password=request.getParameter("password");
		
		System.out.println(password);
		
		
		LoginDetails login=new LoginDetails( userName,password);
		LoginDetailsDao LD=new LoginDetailsDao();
	
	
			try {
				if(LD.loginCheck(login))
				{
					System.out.println("Welcome to login "+userName);
					session.setAttribute("user", login);
					
					//request.setAttribute("list", employee);
					
					page="Home.jsp";
					
					//RequestDispatcher RD=request.getRequestDispatcher("success.jsp");
					//RD.forward(request, response);
					
				}
					 
				else
					{
					System.out.println("Sorry "+userName+" Not registered");
					
					request.setAttribute("error", "username or password is incorrect");
					
					page="SelfLogin.jsp";
					
					
					}
			} catch (MedicineShopException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
				
		

		RequestDispatcher RD=request.getRequestDispatcher(page);
		RD.forward(request, response);
					
		
	}
	

}
