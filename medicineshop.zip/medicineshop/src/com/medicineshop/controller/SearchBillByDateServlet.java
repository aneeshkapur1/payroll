package com.medicineshop.controller;

import java.io.IOException;
import java.sql.Connection;
import java.sql.Date;
import java.util.ArrayList;
import java.util.List;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.medicineshop.dao.BillsDao;
import com.medicineshop.exception.MedicineShopException;
import com.medicineshop.model.Bills;
import com.medicineshop.util.ConnectionUtil;

/**
 * Servlet implementation class SearchBillByDateServlet
 */
@WebServlet("/SearchBillByDateServlet")
public class SearchBillByDateServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public SearchBillByDateServlet() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		
		Connection connObj=null;
		List<Bills> billList=new ArrayList<Bills>();
		String sD=request.getParameter("startDate");
		String eD=request.getParameter("endDate");
		
		System.out.println(sD);
		System.out.println(eD);
		
		Date startDate=Date.valueOf(sD);
		Date endDate=Date.valueOf(eD);
		
		BillsDao billDao=new BillsDao();
		
		try {
			connObj=ConnectionUtil.getConnection();
			billList=billDao.searchBillByDate(startDate, endDate, connObj);
			
			System.out.println(billList);
			
			request.setAttribute("billList",billList );
			
			request.getRequestDispatcher("SearchBillByDate.jsp").forward(request, response);
			
			
		} catch (MedicineShopException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		
		
		
		
		
		
	}

}
