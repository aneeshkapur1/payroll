package com.medicineshop.controller;

import java.io.IOException;
import java.sql.Connection;
import java.sql.SQLException;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.medicineshop.dao.MedicineDao;
import com.medicineshop.dao.MedicineTypeDao;
import com.medicineshop.exception.MedicineShopException;
import com.medicineshop.model.Medicine;
import com.medicineshop.model.MedicineType;
import com.medicineshop.util.ConnectionUtil;

/**
 * Servlet implementation class UpdateMedicineServlet
 */
@WebServlet("/UpdateMedicineServlet")
public class UpdateMedicineServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public UpdateMedicineServlet() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		
		Connection connObj = null;
		try {
			connObj = ConnectionUtil.getConnection();
			connObj.setAutoCommit(false);
			
			int medId=Integer.parseInt(request.getParameter("mId"));
			String medName=request.getParameter("medicineName");
			int medPS=Integer.parseInt(request.getParameter("itemsPerStrip"));
			int medTypeId=Integer.parseInt(request.getParameter("medTypeId"));
			float cp=Float.parseFloat(request.getParameter("buyingPrice"));
			float sp=Float.parseFloat(request.getParameter("sellingPrice"));
			
			MedicineTypeDao medTypeDao=new MedicineTypeDao();
			MedicineType mediType=medTypeDao.searchMedicineType(medTypeId,connObj );
			
			Medicine med=new Medicine(medName,medPS,cp,sp,mediType);
			med.setMedicineId(medId);
			
			
			MedicineDao medicineDao=new MedicineDao();
			medicineDao.updateMedicineDetails(med, connObj);
			
			
			request.setAttribute("update", "Updated Successfully");
			
			connObj.commit();	
			
		} catch (MedicineShopException | SQLException e) {
			// TODO Auto-generated catch block
			try {
				connObj.rollback();
			} catch (SQLException e1) {
				// TODO Auto-generated catch block
				e1.printStackTrace();
			}
			e.printStackTrace();
		}
		
		RequestDispatcher rd=request.getRequestDispatcher("Home.jsp");
		rd.forward(request, response);
	}
	

}
