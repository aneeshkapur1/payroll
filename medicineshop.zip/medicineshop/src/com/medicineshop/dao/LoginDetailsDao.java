package com.medicineshop.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import com.medicineshop.exception.MedicineShopException;
import com.medicineshop.model.LoginDetails;
import com.medicineshop.util.ConnectionUtil;


public class LoginDetailsDao {

	public LoginDetailsDao() {
		// TODO Auto-generated constructor stub
	}
	
	public boolean loginCheck(LoginDetails user) throws MedicineShopException
	{
		boolean flag=false;
		String query="Select * from login where admin_email=? and admin_password=? ";
		Connection connObj=null;
		PreparedStatement ps=null;
		ResultSet rs=null;
		try {
			connObj=ConnectionUtil.getConnection();
			ps=connObj.prepareStatement(query);
			ps.setString(1, user.getEmail());
			ps.setString(2, user.getPassword());
			
			 rs=ps.executeQuery();
			 if(rs.next())
			 {
				 flag=true;
			 }
		} catch (Exception e) {
			// TODO Auto-generated catch block
			throw new MedicineShopException("Error in login check"+e);
		}
		finally
		{
			if(rs!=null)
			{
				try {
					rs.close();
				} catch (SQLException e) {
					// TODO Auto-generated catch block
					throw new MedicineShopException("Error in closing ResultSet"+e);
				}
			}
			
			if(ps!=null)
			{
				try {
					ps.close();
				} catch (SQLException e) {
					// TODO Auto-generated catch block
					throw new MedicineShopException("Error in closing Prepared Statement"+e);
				}
			}
			
			
		}
		return flag;
	}

}
