package com.medicineshop.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import com.medicineshop.exception.MedicineShopException;
import com.medicineshop.model.PatientDetails;



public class PatientDetailsDao {

	public PatientDetailsDao() {
		// TODO Auto-generated constructor stub
	}

	public int registerPatientDetails(PatientDetails patientDetails,Connection connObj ) throws MedicineShopException
	{
		int count=0;
		PreparedStatement ps=null;
		ResultSet rs=null;
		int generatedID = 0;
		String query="insert into patient_details(patient_name,doctor_name,age,gender,email) values(?,?,?,?,?)";
		try{
			ps=connObj.prepareStatement(query);
			ps.setString(1,patientDetails.getPatientName());
			ps.setString(2,patientDetails.getDoctorName());
			ps.setInt(3,patientDetails.getAge());
			ps.setString(4, patientDetails.getGender());
			ps.setString(5, patientDetails.getEmail());
			count=ps.executeUpdate();
			if(count>0)
			{
				System.out.println("update");
				rs=ps.getGeneratedKeys();
				
				if(rs.next())
				{
					generatedID=rs.getInt(1);
				}
			}
			else
				System.out.println("not update");
		}
		catch(Exception e)
		{
			throw new MedicineShopException("Error on updating new medicine_type"+e);
		}
		 
		finally
		{
			if(rs!=null)
			{
				try {
					rs.close();
				} catch (SQLException e) {
					// TODO Auto-generated catch block
					throw new MedicineShopException("Error in closing ResultSet"+e);
				}
			}
			
			if(ps!=null)
			{
				try {
					ps.close();
				} catch (SQLException e) {
					// TODO Auto-generated catch block
					throw new MedicineShopException("Error in closing Prepared Statement"+e);
				}
			}
			
			
		}
		
		
		
		//ps.setInt(1, address. getAddressID());
		
		return generatedID;
		
	}
	
	public int updatePatientDetails(PatientDetails patientDetails,Connection connObj ) throws MedicineShopException 
	{
		int count=0;
		//Connection connObj = null;
		PreparedStatement ps=null;
		ResultSet rs=null;
		String query="update patient_details set patient_name=?,doctor_name=?,age=?,gender=?,email=?  where patient_id=?";
		try {
			ps=connObj.prepareStatement(query);
			ps.setString(1,patientDetails.getPatientName());
			ps.setString(2,patientDetails.getDoctorName());
			ps.setInt(3,patientDetails.getAge());
			ps.setString(4, patientDetails.getGender());
			ps.setString(5, patientDetails.getEmail());
			ps.setInt(6,patientDetails.getPatientId() );
			
			count=ps.executeUpdate();
			
			
		} catch(Exception e)
		{
			throw new MedicineShopException("Error in Updating medicine_type"+e);
		}
		 
		finally
		{
			if(rs!=null)
			{
				try {
					rs.close();
				} catch (SQLException e) {
					// TODO Auto-generated catch block
					throw new MedicineShopException("Error in closing ResultSet"+e);
				}
			}
			
			if(ps!=null)
			{
				try {
					ps.close();
				} catch (SQLException e) {
					// TODO Auto-generated catch block
					throw new MedicineShopException("Error in closing Prepared Statement"+e);
				}
			}
			
			
		}
		
		return count;
		
	}
	
	public PatientDetails searchPatient(PatientDetails patientDetails,Connection connObj) throws MedicineShopException
	{
		String query="Select *  from patient_details where  patient_name=? and doctor_name=? ";
		PreparedStatement ps=null;
		ResultSet rs=null;
		PatientDetails patient = null;
		
		try {
			ps=connObj.prepareStatement(query);
			
			ps.setString(1,patientDetails.getPatientName());
			ps.setString(2, patientDetails.getDoctorName());
			
			 rs=ps.executeQuery();
			 if(rs.next())
			 {
				 int id=rs.getInt("patient_id");
				 String patientName=rs.getString("patient_name");
				 String doctorName=rs.getString("doctor_name");
				 int age=rs.getInt("age");
				 String gender=rs.getString("gender");
				 String email=rs.getString("email");
				 
				 patient=new PatientDetails(id, patientName, doctorName, age, gender, email);
				 System.out.println(patient);
				 
			 }
		} catch (Exception e) {
			// TODO Auto-generated catch block
			throw new MedicineShopException("Error in login check"+e);
		}
		finally
		{
			if(rs!=null)
			{
				try {
					rs.close();
				} catch (SQLException e) {
					// TODO Auto-generated catch block
					throw new MedicineShopException("Error in closing ResultSet"+e);
				}
			}
			
			if(ps!=null)
			{
				try {
					ps.close();
				} catch (SQLException e) {
					// TODO Auto-generated catch block
					throw new MedicineShopException("Error in closing Prepared Statement"+e);
				}
			}
			
			
		}
		return patient;
	}
}
