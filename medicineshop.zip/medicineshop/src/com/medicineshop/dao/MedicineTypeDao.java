package com.medicineshop.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import com.medicineshop.exception.MedicineShopException;

import com.medicineshop.model.MedicineType;


public class MedicineTypeDao {

	public MedicineTypeDao() {
		// TODO Auto-generated constructor stub
	}
	
	public int registerMedicineType(MedicineType medicineType,Connection connObj ) throws MedicineShopException
	{
		int count=0;
		PreparedStatement ps=null;
		ResultSet rs=null;
		int generatedID = 0;
		String query="insert into medicine_type(medicine_type) values(?)";
		try{
			ps=connObj.prepareStatement(query);
			ps.setString(1,medicineType.getMedicineType());
			count=ps.executeUpdate();
			if(count>0)
			{
				System.out.println("update");
				rs=ps.getGeneratedKeys();
				
				if(rs.next())
				{
					generatedID=rs.getInt(1);
				}
			}
			else
				System.out.println("not update");
		}
		catch(Exception e)
		{
			throw new MedicineShopException("Error on updating new medicine_type"+e);
		}
		 
		finally
		{
			if(rs!=null)
			{
				try {
					rs.close();
				} catch (SQLException e) {
					// TODO Auto-generated catch block
					throw new MedicineShopException("Error in closing ResultSet"+e);
				}
			}
			
			if(ps!=null)
			{
				try {
					ps.close();
				} catch (SQLException e) {
					// TODO Auto-generated catch block
					throw new MedicineShopException("Error in closing Prepared Statement"+e);
				}
			}
			
			
		}
		
		
		
		//ps.setInt(1, address. getAddressID());
		
		return generatedID;
		
	}
	
	public int updateMedicineType(MedicineType medicineType,Connection connObj ) throws MedicineShopException 
	{
		int count=0;
		//Connection connObj = null;
		PreparedStatement ps=null;
		ResultSet rs=null;
		String query="update medicine_type set medicine_type  where medicine_type_id=?";
		try {
			ps=connObj.prepareStatement(query);
			ps.setString(1,medicineType.getMedicineType());
			ps.setInt(2,medicineType.getMedicineTypeId() );
			
			count=ps.executeUpdate();
			
			
		} catch(Exception e)
		{
			throw new MedicineShopException("Error in Updating medicine_type"+e);
		}
		 
		finally
		{
			if(rs!=null)
			{
				try {
					rs.close();
				} catch (SQLException e) {
					// TODO Auto-generated catch block
					throw new MedicineShopException("Error in closing ResultSet"+e);
				}
			}
			
			if(ps!=null)
			{
				try {
					ps.close();
				} catch (SQLException e) {
					// TODO Auto-generated catch block
					throw new MedicineShopException("Error in closing Prepared Statement"+e);
				}
			}
			
			
		}
		
		return count;
		
	}
	public MedicineType searchMedicineType(int medTypeId,Connection connObj ) throws MedicineShopException
	{
		
		MedicineType medicineType=null;
		String query="Select *  from  medicine_type mt where medicine_type_id= ? ";
		PreparedStatement ps=null;
		ResultSet rs=null;
		try {
			ps=connObj.prepareStatement(query);
			
			
			ps.setInt(1,medTypeId);
			
			
			 rs=ps.executeQuery();
			 if(rs.next())
			 { 
				 String medType=rs.getString("medicine_type");
				 
				medicineType=new  MedicineType(medTypeId,medType);
 
				 
				 
			 }
		} catch (Exception e) {
			// TODO Auto-generated catch block
			throw new MedicineShopException("Error in Patient Search"+e);
		}
		finally
		{
			if(rs!=null)
			{
				try {
					rs.close();
				} catch (SQLException e) {
					// TODO Auto-generated catch block
					throw new MedicineShopException("Error in closing ResultSet"+e);
				}
			}
			
			if(ps!=null)
			{
				try {
					ps.close();
				} catch (SQLException e) {
					// TODO Auto-generated catch block
					throw new MedicineShopException("Error in closing Prepared Statement"+e);
				}
			}
			
			
		}
		return medicineType;
	}
	
	public List<MedicineType> searchAllTypeList(Connection connObj ) throws MedicineShopException
	{
		
		List<MedicineType> typeList=new ArrayList<MedicineType>();
		String query="Select *  from  medicine_type mt ";
		PreparedStatement ps=null;
		ResultSet rs=null;
		try {
			ps=connObj.prepareStatement(query);
			
			
			
			
			
			 rs=ps.executeQuery();
			 while(rs.next())
			 { 
				 String medType=rs.getString("medicine_type");
				int medTypeId=rs.getInt("medicine_type_id");
						 
				 
				 MedicineType medicineType=new  MedicineType(medTypeId,medType);
				 typeList.add(medicineType);
				 
				 
			 }
		} catch (Exception e) {
			// TODO Auto-generated catch block
			throw new MedicineShopException("Error in Patient Search"+e);
		}
		finally
		{
			if(rs!=null)
			{
				try {
					rs.close();
				} catch (SQLException e) {
					// TODO Auto-generated catch block
					throw new MedicineShopException("Error in closing ResultSet"+e);
				}
			}
			
			if(ps!=null)
			{
				try {
					ps.close();
				} catch (SQLException e) {
					// TODO Auto-generated catch block
					throw new MedicineShopException("Error in closing Prepared Statement"+e);
				}
			}
			
			
		}
		return typeList;
	}

}
