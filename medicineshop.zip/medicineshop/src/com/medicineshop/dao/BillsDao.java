package com.medicineshop.dao;

import java.sql.Connection;
import java.sql.Date;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import com.medicineshop.exception.MedicineShopException;
import com.medicineshop.model.Bills;
import com.medicineshop.model.PatientDetails;


public class BillsDao {

	public BillsDao() {
		// TODO Auto-generated constructor stub
	}
	
	
	public int registerBillDetails(Bills bill,Connection connObj ) throws MedicineShopException
	{
		int count=0;
		PreparedStatement ps=null;
		ResultSet rs=null;
		int generatedID = 0;
		String query="insert into bill(bill_date,total_amount,total_cost_price,fk_patient_id) values(?,?,?,?)";
		try{
			
			ps=connObj.prepareStatement(query);
			
			ps.setDate(1,bill.getBillDate());
			ps.setInt(2,0);
			ps.setInt(3,0);
			ps.setInt(4, bill.getPatientDetails().getPatientId());
			
			count=ps.executeUpdate();
			
			if(count>0)
			{
				System.out.println("update");
				rs=ps.getGeneratedKeys();
				
				if(rs.next())
				{
					generatedID=rs.getInt(1);
				}
			}
			else
				System.out.println("not update");
		}
		catch(Exception e)
		{
			throw new MedicineShopException("Error on updating new bill"+e);
		}
		 
		finally
		{
			if(rs!=null)
			{
				try {
					rs.close();
				} catch (SQLException e) {
					// TODO Auto-generated catch block
					throw new MedicineShopException("Error in closing ResultSet"+e);
				}
			}
			
			if(ps!=null)
			{
				try {
					ps.close();
				} catch (SQLException e) {
					// TODO Auto-generated catch block
					throw new MedicineShopException("Error in closing Prepared Statement"+e);
				}
			}
			
			
		}
		
		
		
		//ps.setInt(1, address. getAddressID());
		
		return generatedID;
		
	}
	
	public int updateBillAmount(Bills bill,Connection connObj ) throws MedicineShopException 
	{
		int count=0;
		//Connection connObj = null;
		PreparedStatement ps=null;
		ResultSet rs=null;
		String query="update bill set total_amount=?,total_cost_price=? where bill_id=?";
		try {
			ps=connObj.prepareStatement(query);
			
			ps.setFloat(1,bill.getTotalAmount());
			ps.setFloat(2,bill.getTotalCostPrice());
			ps.setInt(3,bill.getBillId() );
			
			count=ps.executeUpdate();
			
			
		} catch(Exception e)
		{
			throw new MedicineShopException("Error in Updating medicine_type"+e);
		}
		 
		finally
		{
			if(rs!=null)
			{
				try {
					rs.close();
				} catch (SQLException e) {
					// TODO Auto-generated catch block
					throw new MedicineShopException("Error in closing ResultSet"+e);
				}
			}
			
			if(ps!=null)
			{
				try {
					ps.close();
				} catch (SQLException e) {
					// TODO Auto-generated catch block
					throw new MedicineShopException("Error in closing Prepared Statement"+e);
				}
			}
			
			
		}
		
		return count;
		
	}
	
	public List<Bills> searchBillByDate(Date startDate,Date endDate,Connection connObj) throws MedicineShopException
	{
		String query="Select *  from patient_details p join bill b  on p.patient_id=b.fk_patient_id where  b.bill_date between ? and ?";
		PreparedStatement ps=null;
		ResultSet rs=null;
		List<Bills> billList=new ArrayList<Bills>();
		
		
		try {
			ps=connObj.prepareStatement(query);
			
			ps.setDate(1, startDate);
			ps.setDate(2, endDate);
			
			 rs=ps.executeQuery();
			 while(rs.next())
			 {
				 int id=rs.getInt("bill_id");
				 String patientName=rs.getString("patient_name");
				 String doctorName=rs.getString("doctor_name");
				 Date billDate=rs.getDate("bill_date");
				 Float totalAmount=rs.getFloat("total_amount");
				 Float totalCP=rs.getFloat("total_cost_price");
				 int pId=rs.getInt("patient_id");
				 
				 PatientDetails patient=new PatientDetails( pId,patientName, doctorName);
				 Bills bill=new Bills();
				 bill.setBillDate(billDate);
				 bill.setBillId(id);
				 bill.setPatientDetails(patient);
				 bill.setTotalAmount(totalAmount);
				 bill.setTotalCostPrice(totalCP);
				 
				 billList.add(bill);
				 
				 
			 }
		} catch (Exception e) {
			// TODO Auto-generated catch block
			throw new MedicineShopException("Error in login check"+e);
		}
		finally
		{
			if(rs!=null)
			{
				try {
					rs.close();
				} catch (SQLException e) {
					// TODO Auto-generated catch block
					throw new MedicineShopException("Error in closing ResultSet"+e);
				}
			}
			
			if(ps!=null)
			{
				try {
					ps.close();
				} catch (SQLException e) {
					// TODO Auto-generated catch block
					throw new MedicineShopException("Error in closing Prepared Statement"+e);
				}
			}
			
			
		}
		return billList;
	}
	
	public Bills searchBillById(int billId,Connection connObj) throws MedicineShopException
	{
		String query="Select *  from patient_details p join bill b  on p.patient_id=b.fk_patient_id where  b.bill_id=?";
		PreparedStatement ps=null;
		ResultSet rs=null;
		Bills bill = null;
		
		
		try {
			ps=connObj.prepareStatement(query);
			
			ps.setInt(1, billId);
			
			 rs=ps.executeQuery();
			 if(rs.next())
			 {
				 int id=rs.getInt("bill_id");
				 String patientName=rs.getString("patient_name");
				 String doctorName=rs.getString("doctor_name");
				 Date billDate=rs.getDate("bill_date");
				 Float totalAmount=rs.getFloat("total_amount");
				 Float totalCP=rs.getFloat("total_cost_price");
				 int pId=rs.getInt("patient_id");
				 int age=rs.getInt("age");
				 String gender=rs.getString("gender");
				 String email=rs.getString("email");
				 
				 
				 PatientDetails patient=new PatientDetails( pId,patientName, doctorName,age,gender,email);
				 bill=new Bills();
				 bill.setBillDate(billDate);
				 bill.setBillId(id);
				 bill.setPatientDetails(patient);
				 bill.setTotalAmount(totalAmount);
				 bill.setTotalCostPrice(totalCP);
				
				 
				 
			 }
		} catch (Exception e) {
			// TODO Auto-generated catch block
			throw new MedicineShopException("Error in login check"+e);
		}
		finally
		{
			if(rs!=null)
			{
				try {
					rs.close();
				} catch (SQLException e) {
					// TODO Auto-generated catch block
					throw new MedicineShopException("Error in closing ResultSet"+e);
				}
			}
			
			if(ps!=null)
			{
				try {
					ps.close();
				} catch (SQLException e) {
					// TODO Auto-generated catch block
					throw new MedicineShopException("Error in closing Prepared Statement"+e);
				}
			}
			
			
		}
		return bill;
	}
	
	public List<Bills> ListAllBills(Connection connObj) throws MedicineShopException
	{
		String query="Select *  from patient_details p join bill b  on p.patient_id=b.fk_patient_id ";
		PreparedStatement ps=null;
		ResultSet rs=null;
		List<Bills> billList=new ArrayList<Bills>();
		
		
		try {
			ps=connObj.prepareStatement(query);
			

			
			 rs=ps.executeQuery();
			 while(rs.next())
			 {
				 int id=rs.getInt("bill_id");
				 String patientName=rs.getString("patient_name");
				 String doctorName=rs.getString("doctor_name");
				 Date billDate=rs.getDate("bill_date");
				 Float totalAmount=rs.getFloat("total_amount");
				 Float totalCP=rs.getFloat("total_cost_price");
				 int pId=rs.getInt("patient_id");
				 
				 PatientDetails patient=new PatientDetails( pId,patientName, doctorName);
				 Bills bill=new Bills();
				 bill.setBillDate(billDate);
				 bill.setBillId(id);
				 bill.setPatientDetails(patient);
				 bill.setTotalAmount(totalAmount);
				 bill.setTotalCostPrice(totalCP);
				 
				 billList.add(bill);
				 
				 
			 }
		} catch (Exception e) {
			// TODO Auto-generated catch block
			throw new MedicineShopException("Error in login check"+e);
		}
		finally
		{
			if(rs!=null)
			{
				try {
					rs.close();
				} catch (SQLException e) {
					// TODO Auto-generated catch block
					throw new MedicineShopException("Error in closing ResultSet"+e);
				}
			}
			
			if(ps!=null)
			{
				try {
					ps.close();
				} catch (SQLException e) {
					// TODO Auto-generated catch block
					throw new MedicineShopException("Error in closing Prepared Statement"+e);
				}
			}
			
			
		}
		return billList;
	}

}
