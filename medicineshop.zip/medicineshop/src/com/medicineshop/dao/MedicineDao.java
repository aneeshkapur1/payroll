package com.medicineshop.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import com.medicineshop.exception.MedicineShopException;
import com.medicineshop.model.Medicine;
import com.medicineshop.model.MedicineType;


public class MedicineDao {

	public MedicineDao() {
		// TODO Auto-generated constructor stub
	}
	
	public int registerMedicineDetails(Medicine medicine,Connection connObj ) throws MedicineShopException
	{
		int count=0;
		PreparedStatement ps=null;
		ResultSet rs=null;
		int generatedID = 0;
		String query="insert into medicine(medicine_name,items_per_strip,buying_price,selling_price,fk_medicine_type_id) values(?,?,?,?,?)";
		try{
			ps=connObj.prepareStatement(query);
			ps.setString(1,medicine.getMedicineName());
			ps.setInt(2,medicine.getItemsPerStrip());
			ps.setFloat(3, medicine.getBuyingPrice());
			ps.setFloat(4, medicine.getSellingPrice());
			ps.setInt(5, medicine.getMedicineType().getMedicineTypeId());
		
			
			count=ps.executeUpdate();
			if(count>0)
			{
				System.out.println("update");
				rs=ps.getGeneratedKeys();
				
				if(rs.next())
				{
					generatedID=rs.getInt(1);
				}
			}
			else
				System.out.println("not update");
		}
		catch(Exception e)
		{
			throw new MedicineShopException("Error on updating new medicine"+e);
		}
		 
		finally
		{
			if(rs!=null)
			{
				try {
					rs.close();
				} catch (SQLException e) {
					// TODO Auto-generated catch block
					throw new MedicineShopException("Error in closing ResultSet"+e);
				}
			}
			
			if(ps!=null)
			{
				try {
					ps.close();
				} catch (SQLException e) {
					// TODO Auto-generated catch block
					throw new MedicineShopException("Error in closing Prepared Statement"+e);
				}
			}
			
			
		}
		
		
		
		//ps.setInt(1, address. getAddressID());
		
		return generatedID;
		
	}
	
	public int updateMedicineDetails(Medicine medicine,Connection connObj ) throws MedicineShopException 
	{
		int count=0;
		//Connection connObj = null;
		PreparedStatement ps=null;
		ResultSet rs=null;
		String query="update medicine set medicine_name=?,items_per_strip=?,buying_price=?,selling_price=?,fk_medicine_type_id=?  where medicine_id=?";
		try {
			ps=connObj.prepareStatement(query);
			ps.setString(1,medicine.getMedicineName());
			ps.setInt(2,medicine.getItemsPerStrip());
			ps.setFloat(3, medicine.getBuyingPrice());
			ps.setFloat(4, medicine.getSellingPrice());
			ps.setInt(5, medicine.getMedicineType().getMedicineTypeId());
			ps.setInt(6, medicine.getMedicineId());
		
			
			count=ps.executeUpdate();
			
			
		} catch(Exception e)
		{
			throw new MedicineShopException("Error in Updating medicine"+e);
		}
		 
		finally
		{
			if(rs!=null)
			{
				try {
					rs.close();
				} catch (SQLException e) {
					// TODO Auto-generated catch block
					throw new MedicineShopException("Error in closing ResultSet"+e);
				}
			}
			
			if(ps!=null)
			{
				try {
					ps.close();
				} catch (SQLException e) {
					// TODO Auto-generated catch block
					throw new MedicineShopException("Error in closing Prepared Statement"+e);
				}
			}
			
			
		}
		
		return count;
		
	}
	
	public List<Medicine> searchMedicineByName(String medicine,Connection connObj ) throws MedicineShopException
	{
		String query="Select *  from medicine m join medicine_type mt on m.fk_medicine_type_id=mt.medicine_type_id  where m.medicine_name like ? ";
		PreparedStatement ps=null;
		ResultSet rs=null;
		List<Medicine> medList=new ArrayList<Medicine>();
		try {
			ps=connObj.prepareStatement(query);
			String s="%"+medicine+"%";
			
			ps.setString(1,s);
			
			
			 rs=ps.executeQuery();
			 while(rs.next())
			 {
				 int medId =rs.getInt("medicine_id");
				 String medName=rs.getString("medicine_name");
				 int itemsPS =rs.getInt("items_per_strip");
				 float cp=rs.getFloat("buying_price");
				 float sp=rs.getFloat("selling_price");
				 
				 int medTypeId=rs.getInt("medicine_type_id");
				 String medType=rs.getString("medicine_type");
				 
				 MedicineType medicineType=new  MedicineType(medTypeId,medType);
				 
				 
				 Medicine med=new Medicine(medName,itemsPS,cp,sp,medicineType);
				 med.setMedicineId(medId);
				 
				 medList.add(med);
				 
			 }
		} catch (Exception e) {
			// TODO Auto-generated catch block
			throw new MedicineShopException("Error in Patient Search"+e);
		}
		finally
		{
			if(rs!=null)
			{
				try {
					rs.close();
				} catch (SQLException e) {
					// TODO Auto-generated catch block
					throw new MedicineShopException("Error in closing ResultSet"+e);
				}
			}
			
			if(ps!=null)
			{
				try {
					ps.close();
				} catch (SQLException e) {
					// TODO Auto-generated catch block
					throw new MedicineShopException("Error in closing Prepared Statement"+e);
				}
			}
			
			
		}
		return medList;
	}
	
	
	public Medicine searchMedicineById(int medId,Connection connObj ) throws MedicineShopException
	{
		String query="Select *  from medicine m join medicine_type mt on m.fk_medicine_type_id=mt.medicine_type_id  where m.medicine_Id = ? ";
		PreparedStatement ps=null;
		ResultSet rs=null;
		Medicine med=null;
		try {
			ps=connObj.prepareStatement(query);
			
			
			ps.setInt(1,medId);
			
			
			 rs=ps.executeQuery();
			 while(rs.next())
			 {
				
				 String medName=rs.getString("medicine_name");
				 int itemsPS =rs.getInt("items_per_strip");
				 float cp=rs.getFloat("buying_price");
				 float sp=rs.getFloat("selling_price");
				 
				 int medTypeId=rs.getInt("medicine_type_id");
				 String medType=rs.getString("medicine_type");
				 
				 MedicineType medicineType=new  MedicineType(medTypeId,medType);
				 
				 
				 med=new Medicine(medName,itemsPS,cp,sp,medicineType);
				 med.setMedicineId(medId);
				 

			 }
		} catch (Exception e) {
			// TODO Auto-generated catch block
			throw new MedicineShopException("Error in Patient Search"+e);
		}
		finally
		{
			if(rs!=null)
			{
				try {
					rs.close();
				} catch (SQLException e) {
					// TODO Auto-generated catch block
					throw new MedicineShopException("Error in closing ResultSet"+e);
				}
			}
			
			if(ps!=null)
			{
				try {
					ps.close();
				} catch (SQLException e) {
					// TODO Auto-generated catch block
					throw new MedicineShopException("Error in closing Prepared Statement"+e);
				}
			}
			
			
		}
		return med;
	}
	
	public int deleteMedicine(int medId,Connection connObj ) throws MedicineShopException 
	{
		int count=0;
		//Connection connObj = null;
		PreparedStatement ps=null;
		ResultSet rs=null;
		String query="delete from  medicine where medicine_id=?";
		try {

			ps=connObj.prepareStatement(query);
			
			
			ps.setInt(1,medId);
			
			
			count=ps.executeUpdate();
			
			
		} catch(Exception e)
		{
			throw new MedicineShopException("Error in deleting medicine"+e);
		}
		 
		finally
		{
			if(rs!=null)
			{
				try {
					rs.close();
				} catch (SQLException e) {
					// TODO Auto-generated catch block
					throw new MedicineShopException("Error in closing ResultSet"+e);
				}
			}
			
			if(ps!=null)
			{
				try {
					ps.close();
				} catch (SQLException e) {
					// TODO Auto-generated catch block
					throw new MedicineShopException("Error in closing Prepared Statement"+e);
				}
			}
			
			
		}
		
		return count;
		
	}
	
	
}
