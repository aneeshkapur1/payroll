package com.medicineshop.dao;

import java.sql.Connection;
import java.sql.Date;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;

import java.util.List;

import com.medicineshop.exception.MedicineShopException;
import com.medicineshop.model.BillMedicineTransaction;
import com.medicineshop.model.Bills;
import com.medicineshop.model.Medicine;
import com.medicineshop.model.MedicineType;
import com.medicineshop.model.PatientDetails;


public class BillMedicineTransactionDao {

	public BillMedicineTransactionDao() {
		// TODO Auto-generated constructor stub
	}
	
	public int registerBillMedicineTransaction(Medicine med,Bills bill,int quantity,Connection connObj ) throws MedicineShopException
	{
		int count=0;
		PreparedStatement ps=null;
		ResultSet rs=null;
		int generatedID = 0;
		String query="insert into transaction( transaction_date,fk_bill_id,fk_medicine_id, quantity) values(?,?,?,?)";
		try{
			ps=connObj.prepareStatement(query);
			
			ps.setDate(1, bill.getBillDate());
			ps.setInt(2, bill.getBillId());
			ps.setInt(3, med.getMedicineId());
			ps.setInt(4, quantity);
			count=ps.executeUpdate();
			if(count>0)
			{
				System.out.println("update");
				rs=ps.getGeneratedKeys();
				
				if(rs.next())
				{
					generatedID=rs.getInt(1);
				}
			}
			else
				System.out.println("not update");
		}
		catch(Exception e)
		{
			throw new MedicineShopException("Error on updating new medicine_type"+e);
		}
		 
		finally
		{
			if(rs!=null)
			{
				try {
					rs.close();
				} catch (SQLException e) {
					// TODO Auto-generated catch block
					throw new MedicineShopException("Error in closing ResultSet"+e);
				}
			}
			
			if(ps!=null)
			{
				try {
					ps.close();
				} catch (SQLException e) {
					// TODO Auto-generated catch block
					throw new MedicineShopException("Error in closing Prepared Statement"+e);
				}
			}
			
			
		}
		return generatedID;
		
	}
	
	public int removeMedicineByBill(int tId,Connection connObj) throws MedicineShopException
	{
		int count=0;
		PreparedStatement ps=null;
		ResultSet rs=null;
		String query="delete from transaction where transaction_id=?";
		try {
		ps=connObj.prepareStatement(query);
		
		ps.setInt(1,tId);
		count=ps.executeUpdate();
		
		} catch (Exception e) {
			// TODO Auto-generated catch block
			throw new MedicineShopException("Error in Transaction delete"+e);
		}
		finally
		{
			if(rs!=null)
			{
				try {
					rs.close();
				} catch (SQLException e) {
					// TODO Auto-generated catch block
					throw new MedicineShopException("Error in closing ResultSet"+e);
				}
			}
			
			if(ps!=null)
			{
				try {
					ps.close();
				} catch (SQLException e) {
					// TODO Auto-generated catch block
					throw new MedicineShopException("Error in closing Prepared Statement"+e);
				}
			}
			
			
		}
		
		return count;
		
	}
	
	public List<BillMedicineTransaction> searchMedicineByBillId(int bId,Connection connObj ) throws MedicineShopException
	{
		String query="Select *  from medicine m join medicine_type mt join bill b join transaction t join patient_details p on m.fk_medicine_type_id=mt.medicine_type_id and m.medicine_id=t.fk_medicine_id and b.bill_id=t.fk_bill_id and p.patient_id=b.fk_patient_id where b.bill_id=?";
		PreparedStatement ps=null;
		ResultSet rs=null;
		Bills bill=null;
		float bsp=0,bcp=0;
		List<BillMedicineTransaction> transactionList=new ArrayList<BillMedicineTransaction>();
		try {
			ps=connObj.prepareStatement(query);
			
			
			ps.setInt(1,bId);
			
			
			 rs=ps.executeQuery();
			 while(rs.next())
			 {
				 int medId =rs.getInt("medicine_id");
				 String medName=rs.getString("medicine_name");
				 int itemsPS =rs.getInt("items_per_strip");
				 float cp=rs.getFloat("buying_price");
				 float sp=rs.getFloat("selling_price");
				 int quantity=rs.getInt("quantity");
				 
				 bcp+=cp*quantity;
				 bsp+=sp*quantity;
				 
				 int medTypeId=rs.getInt("medicine_type_id");
				 String medType=rs.getString("medicine_type");
				 
				 MedicineType medicineType=new  MedicineType(medTypeId,medType);
				 
				 
				 Medicine med=new Medicine(medName,itemsPS,cp,sp,medicineType);
				 med.setMedicineId(medId);
				 
				 int billId=rs.getInt("bill_id");
				 Date billDate=rs.getDate("bill_date");
				 float totalAmount=rs.getFloat("total_amount");
				 float totalCP=rs.getFloat("total_cost_price");
				 int pId=rs.getInt("patient_id");
				 String pName=rs.getString("patient_name");
				 String dName=rs.getString("doctor_name");
				 
				
				 
				 PatientDetails patient=new PatientDetails(pId,pName,dName);
				 
				 bill=new Bills(billId, billDate, totalAmount, totalCP,patient);
				 
				 BillMedicineTransaction transaction=new  BillMedicineTransaction(med,bill,quantity);
				 
				 transaction.setTransactionID(rs.getInt("transaction_id"));
				 transactionList.add(transaction);
				 
				
				 
			 }
		} catch (Exception e) {
			// TODO Auto-generated catch block
			throw new MedicineShopException("Error in Patient Search"+e);
		}
		finally
		{
			if(rs!=null)
			{
				try {
					rs.close();
				} catch (SQLException e) {
					// TODO Auto-generated catch block
					throw new MedicineShopException("Error in closing ResultSet"+e);
				}
			}
			
			if(ps!=null)
			{
				try {
					ps.close();
				} catch (SQLException e) {
					// TODO Auto-generated catch block
					throw new MedicineShopException("Error in closing Prepared Statement"+e);
				}
			}
			
			
		}
		bill.setTotalAmount(bsp);
		bill.setTotalCostPrice(bcp);
		return transactionList;
	}

}
