package com.medicineshop.exception;

public class MedicineShopException extends Exception{

	public MedicineShopException(String s) {
		// TODO Auto-generated constructor stub
		super(s);
	}

}
